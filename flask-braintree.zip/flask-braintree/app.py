"""
Order site for virtual machines and domain names.

Customers pay through Braintree (card form = Braintree Drop-in, so card numbers never
reach this server). Everything else lives in MariaDB: customers, cards (token and last
4 digits only), orders, transactions and the domain registrar log. worker.py on the
OpenStack controller reads paid orders from the same database and creates the VM or
registers the domain.

Required environment: see deploy/kb-order.env.example
"""

import hashlib
import hmac
import logging
import os
import re
import secrets

import click
import requests
from flask import Flask, abort, g, redirect, render_template, request, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

import billing
import db
import repo
from bt import Braintree, BraintreeError, Declined
from godaddy import normalize_label, valid_label
from plans import TLD_NOTES, money
from registrar import LoggedRegistrar, RegistrarError, make_registrar

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("orders")

_REQUIRED = ("SECRET_KEY", "DATABASE_URL", "BT_MERCHANT_ID", "BT_PUBLIC_KEY", "BT_PRIVATE_KEY")
_missing = [n for n in _REQUIRED if not os.environ.get(n)]
if _missing:
    raise RuntimeError("Missing required environment variable(s): " + ", ".join(_missing))

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
app.config.update(
    SECRET_KEY=os.environ["SECRET_KEY"],
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "1") == "1",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SITE_NAME=os.environ.get("SITE_NAME", "cloud.lab"),
    SHOW_TEST_CARD_HINT=os.environ.get("SHOW_TEST_CARD_HINT", "1") == "1",
    DATABASE_URL=os.environ["DATABASE_URL"],
)

bt = Braintree(
    os.environ.get("BT_ENVIRONMENT", "sandbox"),
    os.environ["BT_MERCHANT_ID"], os.environ["BT_PUBLIC_KEY"], os.environ["BT_PRIVATE_KEY"],
)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
VM_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,28}[a-z0-9]$")
DOMAIN_TERMS_URL = "https://www.godaddy.com/legal/agreements/domain-name-registration-agreement"


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = db.connect(app.config["DATABASE_URL"])
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def csrf_token() -> str:
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token
app.jinja_env.globals["money"] = money


def check_csrf() -> None:
    sent = request.form.get("csrf_token", "")
    expected = session.get("csrf", "")
    if not expected or not hmac.compare_digest(sent, expected):
        log.warning("CSRF check failed (on plain http set SESSION_COOKIE_SECURE=0)")
        abort(400)


def error_page(title, message, status):
    return render_template("error.html", title=title, message=message), status


def plan_views(product_type):
    out = {}
    for p in repo.list_plans(get_db(), product_type):
        per = "month" if p["billing_period"] == "monthly" else "year"
        out[p["code"]] = {**p, "price": f"{money(p['price_cents'], p['currency'])} per {per}",
                          "note": TLD_NOTES.get(p["tld"]) if p["tld"] else None}
    return out


def tld_views():
    return {v["tld"]: v for v in plan_views("domain").values()}


def clean_customer():
    return {
        "name": request.form.get("name", "").strip(),
        "email": request.form.get("email", "").strip().lower(),
        "nonce": request.form.get("payment_method_nonce", "").strip(),
    }


def customer_errors(form):
    errors = []
    if not 2 <= len(form["name"]) <= 100:
        errors.append("Enter your full name.")
    if len(form["email"]) > 254 or not EMAIL_RE.match(form["email"]):
        errors.append("Enter a valid email address.")
    if not form["nonce"]:
        errors.append("Enter your card details.")
    return errors


def place_order(form, plan, **extra):
    """Customer, card, order row, Braintree subscription. Returns (redirect, None) or (None, (errors, status))."""
    c = get_db()
    try:
        customer, _ = repo.get_or_create_customer(c, form["name"], form["email"])
        bt.ensure_customer(customer["braintree_customer_id"], customer["name"], customer["email"])
        card = bt.add_card(customer["braintree_customer_id"], form["nonce"])
    except Declined:
        return None, (["That card was not accepted. Check the details or try another card."], 402)
    except BraintreeError as exc:
        log.error("Braintree customer/card failed: %s", exc)
        return None, (["We couldn't reach the payment service. Try again in a minute."], 502)
    pm_id = repo.save_payment_method(c, customer["id"], card)

    try:
        order_id, public_id = repo.create_order(c, customer["id"], plan, pm_id, **extra)
    except db.IntegrityError:
        return None, ([f"{extra.get('domain', 'That name')} was just ordered by someone else. Try another name."], 409)

    try:
        sub = bt.subscribe(card["token"], plan["braintree_plan_id"], plan["price_cents"], plan["trial_days"])
    except Declined as exc:
        repo.fail_order(c, order_id, f"Payment declined: {exc}")
        return None, (["The payment was declined. Check the card or try another one."], 402)
    except BraintreeError as exc:
        log.error("Subscription failed for order %s (card token %s): %s", public_id, card["token"], exc)
        repo.fail_order(c, order_id, "Payment service error")
        return None, (["We couldn't complete the payment. You were not charged. Try again in a minute."], 502)

    repo.attach_subscription(c, order_id, sub)
    billing.apply_subscription(c, sub)
    session["customer_id"] = customer["id"]
    session.pop("csrf", None)
    log.info("Order placed: %s plan=%s customer=%s subscription=%s", public_id, plan["code"], customer["id"], sub["id"])
    return redirect(url_for("order_status", public_id=public_id), 303), None


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if not request.path.startswith("/static/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


@app.errorhandler(400)
def bad_request(_exc):
    return error_page("This form has expired", "Reload the page and submit the order again.", 400)


@app.errorhandler(404)
def not_found(_exc):
    return error_page("Page not found", "Check the address, or start a new order.", 404)


# --------------------------------------------------------------------------
# Virtual machines
# --------------------------------------------------------------------------
def render_order(form=None, errors=None, status=200):
    try:
        token = bt.client_token()
    except BraintreeError as exc:
        log.error("%s", exc)
        return error_page("Ordering is unavailable", "The payment service isn't responding. Try again in a few minutes.", 503)
    plans = plan_views("vm")
    wanted = (form or {}).get("plan")
    selected = wanted if wanted in plans else ("compute-vm-basic" if "compute-vm-basic" in plans else next(iter(plans), ""))
    return render_template("order.html", client_token=token, plans=plans, selected_plan=selected,
                           form=form or {}, errors=errors or []), status


@app.get("/")
def order_form():
    return render_order({"plan": request.args.get("plan", "")})


@app.post("/order")
def order_submit():
    check_csrf()
    form = {**clean_customer(), "vm_name": request.form.get("vm_name", "").strip().lower(),
            "plan": request.form.get("plan", "").strip()}
    plan = repo.get_plan(get_db(), form["plan"])
    errors = customer_errors(form)
    if not plan or plan["product_type"] != "vm":
        errors.append("Choose a plan.")
    if not VM_NAME_RE.match(form["vm_name"]):
        errors.append("Name the VM with 3 to 30 lowercase letters, numbers or hyphens, "
                      "starting and ending with a letter or number.")
    if errors:
        return render_order(form, errors, 400)
    response, failure = place_order(form, plan, vm_name=form["vm_name"])
    return response if response else render_order(form, *failure)


# --------------------------------------------------------------------------
# Domains
# --------------------------------------------------------------------------
def registrar_for_site():
    return LoggedRegistrar(make_registrar(get_db()), get_db())


def split_domain(label_raw, tld_raw):
    tld = (tld_raw or "").strip().lower().lstrip(".")
    label = normalize_label(label_raw, tld)
    if not valid_label(label) or not repo.domain_plan_for_tld(get_db(), tld):
        return None, tld, None
    return label, tld, f"{label}.{tld}"


def render_domain_search(form=None, errors=None, result=None, status=200):
    form = form or {}
    if result is None:
        return render_template("domain_search.html", tlds=tld_views(), form=form, errors=errors or []), status
    try:
        token = bt.client_token()
    except BraintreeError as exc:
        log.error("%s", exc)
        return error_page("Ordering is unavailable", "The payment service isn't responding. Try again in a few minutes.", 503)
    return render_template("domain_order.html", client_token=token, tlds=tld_views(), form=form,
                           errors=errors or [], result=result, terms_url=DOMAIN_TERMS_URL), status


def domain_available(domain):
    """(True/False, None) or (None, message). Also false if another order already holds the name."""
    try:
        free = registrar_for_site().check(domain)["available"]
    except RegistrarError as exc:
        log.error("Availability check failed for %s: %s", domain, exc)
        return None, "We couldn't check that name right now. Try again in a minute."
    held = get_db().one("SELECT 1 AS x FROM domain_orders WHERE domain_name = %s", (domain,))
    return free and not held, None


@app.get("/domain")
def domain_form():
    return render_domain_search({"tld": request.args.get("tld", "com")})


@app.post("/domain/search")
def domain_search():
    check_csrf()
    label, tld, domain = split_domain(request.form.get("label"), request.form.get("tld"))
    form = {"label": request.form.get("label", ""), "tld": request.form.get("tld", "com")}
    if not domain:
        return render_domain_search(form, ["Enter a name with letters, numbers or hyphens, and choose .com, .net or .eu."], status=400)
    form = {"label": label, "tld": tld}
    free, problem = domain_available(domain)
    if problem:
        return render_domain_search(form, [problem], status=502)
    if not free:
        return render_domain_search(form, [f"{domain} is already taken. Try another name or extension."])
    return render_domain_search(form, result={"domain": domain, "tld": tld})


@app.post("/domain/order")
def domain_order():
    check_csrf()
    form = {**clean_customer(), "terms": request.form.get("terms") == "on"}
    label, tld, domain = split_domain(request.form.get("label"), request.form.get("tld"))
    if not domain:
        return render_domain_search({"label": request.form.get("label", ""), "tld": request.form.get("tld", "")},
                                    ["Search for a domain name first."], status=400)
    form.update(label=label, tld=tld)
    result = {"domain": domain, "tld": tld}
    errors = customer_errors(form)
    if not form["terms"]:
        errors.append("Accept the domain registration agreement to continue.")
    if errors:
        return render_domain_search(form, errors, result, 400)

    free, problem = domain_available(domain)  # again, right before charging
    if problem:
        return render_domain_search(form, [problem], result, 502)
    if not free:
        return render_domain_search({"label": label, "tld": tld}, [f"{domain} was just taken. Try another name."], status=409)

    plan = repo.domain_plan_for_tld(get_db(), tld)
    response, failure = place_order(form, plan, domain=domain, consent_at=db.now())
    return response if response else render_domain_search(form, failure[0], result, failure[1])


# --------------------------------------------------------------------------
# Order pages
# --------------------------------------------------------------------------
def order_phase(o):
    if o["status"] == "failed":
        return "failed"
    if o["status"] == "cancelled":
        return "inactive"
    if o["fulfillment_status"] == "done":
        return "ready"
    if o["fulfillment_status"] in ("failed", "needs_review"):
        return "problem"
    return "pending"


def order_view(o):
    per = "month" if o["billing_period"] == "monthly" else "year"
    return {**o, "phase": order_phase(o), "price_text": f"{money(o['amount_cents'], o['currency'])} per {per}"}


@app.get("/order/<public_id>")
def order_status(public_id):
    if not re.fullmatch(r"[0-9a-f-]{36}", public_id):
        abort(404)
    o = repo.get_order_by_public_id(get_db(), public_id)
    if not o:
        abort(404)
    return render_template("status.html", o=order_view(o), transactions=repo.transactions_for_order(get_db(), o["id"]))


@app.get("/orders")
def my_orders():
    customer_id = session.get("customer_id")
    orders = [order_view(o) for o in repo.orders_for_customer(get_db(), customer_id)] if customer_id else []
    return render_template("orders.html", orders=orders)


# --------------------------------------------------------------------------
# Braintree webhooks (optional: Braintree can only reach this if the site is public)
# --------------------------------------------------------------------------
@app.route("/braintree/webhook", methods=["GET", "POST"])
def braintree_webhook():
    if request.method == "GET":
        try:
            return bt.gateway.webhook_notification.verify(request.args.get("bt_challenge", ""))
        except Exception:  # noqa: BLE001
            abort(400)
    signature, payload = request.form.get("bt_signature", ""), request.form.get("bt_payload", "")
    try:
        kind, sub = bt.parse_webhook(signature, payload)
    except BraintreeError as exc:
        log.warning("%s", exc)
        abort(400)
    c = get_db()
    digest = hashlib.sha256((signature + payload).encode()).hexdigest()
    try:
        event_id = c.insert(
            "INSERT INTO braintree_events (kind, subscription_id, payload_hash, received_at) VALUES (%s,%s,%s,%s)",
            (kind, sub["id"] if sub else None, digest, db.now()))
        c.commit()
    except db.IntegrityError:
        c.rollback()
        return "duplicate", 200  # Braintree resent something we already handled
    try:
        order_id = billing.apply_subscription(c, sub) if sub else None
    except Exception:  # noqa: BLE001
        log.exception("Webhook %s for %s could not be applied", kind, sub and sub["id"])
        c.rollback()
        c.execute("DELETE FROM braintree_events WHERE id = %s", (event_id,))  # so Braintree's retry is processed
        c.commit()
        return "error", 500
    if sub and order_id is None:
        c.execute("UPDATE braintree_events SET error=%s WHERE id=%s", ("no order for this subscription", event_id))
        c.commit()
    log.info("Webhook %s for %s applied (order %s)", kind, sub and sub["id"], order_id)
    return "ok", 200


@app.get("/healthz")
def healthz():
    get_db().one("SELECT 1 AS ok")
    return "ok"


# --------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------
@app.cli.command("init-db")
def init_db_command():
    """Create the tables (if missing) and load the plans."""
    here = os.path.dirname(os.path.abspath(__file__))
    sql = open(os.path.join(here, "schema.sql")).read()
    c = get_db()
    if c.kind == "sqlite":
        sql = db.sqlite_schema(sql)
    for stmt in (s.strip() for s in re.sub(r"^--.*$", "", sql, flags=re.M).split(";")):
        if stmt:
            c.execute(stmt)
    c.commit()
    repo.seed_plans(c)
    click.echo(f"Tables ready, {len(repo.list_plans(c, 'vm')) + len(repo.list_plans(c, 'domain'))} plans loaded.")


@app.cli.command("check")
def check_command():
    """Confirm the database and Braintree work."""
    row = get_db().one("SELECT COUNT(*) AS n FROM plans")
    click.echo(f"Database OK, {row['n']} plans.")
    try:
        token = bt.client_token()
    except BraintreeError as exc:
        raise click.ClickException(str(exc))
    click.echo(f"Braintree OK (client token {len(token)} characters).")


@app.cli.command("orders")
@click.argument("email")
def orders_command(email):
    """List every order of one customer."""
    for o in repo.orders_for_email(get_db(), email.strip().lower()):
        what = o["domain_name"] or o["vm_name"] or ""
        click.echo(f"{o['public_id']}  {o['plan_code']:<20} {what:<32} {o['status']:<10} {o['fulfillment_status']}")


@app.cli.command("webhook-test")
@click.argument("url")
@click.option("--kind", default="subscription_charged_successfully", show_default=True)
@click.option("--subscription-id", default="webhook-selftest", show_default=True,
              help="Keep the default: a real subscription id would add a dummy charge to that order.")
def webhook_test_command(url, kind, subscription_id):
    """Send a signed sample Braintree notification to URL (for example your ngrok address)."""
    sample = bt.gateway.webhook_testing.sample_notification(kind, subscription_id)
    resp = requests.post(url, data={"bt_signature": sample["bt_signature"], "bt_payload": sample["bt_payload"]},
                         timeout=20)
    click.echo(f"{resp.status_code} {resp.text[:200]}")
    if resp.status_code != 200:
        raise click.ClickException("The site did not accept the notification.")
