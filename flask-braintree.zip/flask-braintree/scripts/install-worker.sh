#!/usr/bin/env bash
# On the OpenStack controller, from the unzipped directory:  sudo bash scripts/install-worker.sh
# Needs /etc/kb-worker.env filled in (deploy/worker.env.example) and the stopped old kb-webhook service.
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"; dest=/opt/kb-worker
[ "$(id -u)" = 0 ] || { echo "Run with sudo"; exit 1; }
[ -f /etc/kb-worker.env ] || { echo "Create /etc/kb-worker.env from deploy/worker.env.example first"; exit 1; }
mkdir -p "$dest"
rsync -a --exclude venv --exclude tests --exclude scripts --exclude deploy --exclude templates --exclude static \
      --exclude app.py --exclude __pycache__ "$here"/ "$dest"/
[ -d "$dest/venv" ] || python3 -m venv "$dest/venv"
"$dest/venv/bin/pip" install -q -r "$dest/requirements.txt"
install -m 644 "$here/deploy/kb-worker.service" /etc/systemd/system/kb-worker.service
systemctl daemon-reload
if systemctl is-active --quiet kb-webhook; then
  echo "Stopping the old kb-webhook service: Kill Bill is no longer used."; systemctl disable --now kb-webhook
fi
set -a; . /etc/kb-worker.env; set +a
"$dest/venv/bin/python" -c "import db,os; c=db.connect(os.environ['DATABASE_URL']); print('database reachable, plans:', c.one('SELECT COUNT(*) n FROM plans')['n'])"
systemctl enable --now kb-worker
sleep 2; systemctl is-active kb-worker
