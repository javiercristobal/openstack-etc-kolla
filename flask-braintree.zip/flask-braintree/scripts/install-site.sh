#!/usr/bin/env bash
# On the Flask VM, from the unzipped directory:  sudo bash scripts/install-site.sh
# Needs MariaDB already set up (deploy/mariadb-setup.sql) and /etc/kb-order.env filled in.
# Keeps the existing venv and env file; old code is saved to /opt/flask-killbill.bak-<time>.
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"; dest=/opt/flask-killbill
[ "$(id -u)" = 0 ] || { echo "Run with sudo"; exit 1; }
[ -f /etc/kb-order.env ] || { echo "Create /etc/kb-order.env from deploy/kb-order.env.example first"; exit 1; }
mkdir -p "$dest"
[ -z "$(ls -A "$dest" 2>/dev/null)" ] || rsync -a --exclude venv "$dest"/ "$dest.bak-$(date +%Y%m%d-%H%M%S)"/
rsync -a --exclude venv --exclude tests --exclude scripts --exclude deploy --exclude __pycache__ "$here"/ "$dest"/
[ -d "$dest/venv" ] || python3 -m venv "$dest/venv"
"$dest/venv/bin/pip" install -q -r "$dest/requirements.txt"
install -m 644 "$here/deploy/kb-order.service" /etc/systemd/system/kb-order.service
systemctl daemon-reload
set -a; . /etc/kb-order.env; set +a
( cd "$dest" && "$dest/venv/bin/flask" --app app init-db && "$dest/venv/bin/flask" --app app check )
systemctl enable --now kb-order
systemctl restart kb-order; sleep 2
curl -fsS -o /dev/null -w "healthz: %{http_code}\n" http://127.0.0.1:8000/healthz
