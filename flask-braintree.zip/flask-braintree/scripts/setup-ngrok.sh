#!/usr/bin/env bash
# On the Flask VM:  sudo bash scripts/setup-ngrok.sh
# Install the ngrok agent first (https://ngrok.com/download) so that `ngrok` is on the PATH.
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
[ "$(id -u)" = 0 ] || { echo "Run with sudo"; exit 1; }
ngrok_bin="$(command -v ngrok || true)"
[ -n "$ngrok_bin" ] || { echo "ngrok is not installed. See https://ngrok.com/download"; exit 1; }
mkdir -p /etc/ngrok
if [ ! -f /etc/ngrok/ngrok.yml ]; then
  install -m 600 -o www-data "$here/deploy/ngrok.yml" /etc/ngrok/ngrok.yml
  echo "Edit /etc/ngrok/ngrok.yml: set your authtoken and domain, then run this script again."
  exit 0
fi
grep -q 'PASTE-YOUR\|REPLACE-WITH' /etc/ngrok/ngrok.yml && { echo "/etc/ngrok/ngrok.yml still has placeholders."; exit 1; }
chown www-data /etc/ngrok/ngrok.yml; chmod 600 /etc/ngrok/ngrok.yml
sed "s#/usr/local/bin/ngrok#$ngrok_bin#" "$here/deploy/ngrok.service" > /etc/systemd/system/ngrok.service
sudo -u www-data "$ngrok_bin" config check --config /etc/ngrok/ngrok.yml
systemctl daemon-reload
systemctl enable --now ngrok
sleep 3; systemctl is-active ngrok
domain="$(grep -m1 'url: https://' /etc/ngrok/ngrok.yml | sed 's/.*url: //')"
echo "Webhook URL for Braintree: ${domain:-<your ngrok domain>}/braintree/webhook"
