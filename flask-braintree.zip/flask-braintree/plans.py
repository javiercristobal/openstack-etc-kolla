"""The products on sale. Seeded into the plans table by `flask --app app init-db`."""

CURRENCY = "USD"

# braintree_plan_id must exist in the Braintree control panel (Recurring Billing > Plans)
# with the matching billing frequency: 1 month for VMs, 12 months for domains.
PLANS = [
    dict(code="compute-vm-basic", product_type="vm", title="Basic", price_cents=1000,
         billing_period="monthly", trial_days=30, braintree_plan_id="compute-vm-basic", flavor="m1.mini"),
    dict(code="compute-vm-medium", product_type="vm", title="Medium", price_cents=2000,
         billing_period="monthly", trial_days=30, braintree_plan_id="compute-vm-medium", flavor="m1.medium"),
    dict(code="compute-vm-large", product_type="vm", title="Large", price_cents=3000,
         billing_period="monthly", trial_days=30, braintree_plan_id="compute-vm-large", flavor="m1.large"),
    dict(code="domain-com-annual", product_type="domain", title=".com domain", price_cents=1800,
         billing_period="yearly", trial_days=0, braintree_plan_id="domain-com-annual", tld="com"),
    dict(code="domain-net-annual", product_type="domain", title=".net domain", price_cents=2000,
         billing_period="yearly", trial_days=0, braintree_plan_id="domain-net-annual", tld="net"),
    dict(code="domain-eu-annual", product_type="domain", title=".eu domain", price_cents=1400,
         billing_period="yearly", trial_days=0, braintree_plan_id="domain-eu-annual", tld="eu"),
]

TLD_NOTES = {
    "eu": "A .eu domain can only be registered by a person or company in the EU, EEA, "
          "Iceland, Liechtenstein or Norway.",
}


def money(cents: int, currency: str = CURRENCY) -> str:
    amount = f"{cents / 100:.2f}".rstrip("0").rstrip(".") if cents % 100 == 0 else f"{cents / 100:.2f}"
    return ("$" if currency == "USD" else currency + " ") + amount
