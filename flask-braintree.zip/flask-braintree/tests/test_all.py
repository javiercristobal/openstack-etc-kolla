import os, sys, tempfile, types, itertools, re
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, ROOT)
DBFILE = tempfile.mktemp(suffix=".db")
os.environ.update(SECRET_KEY="s", DATABASE_URL="sqlite:///" + DBFILE, BT_MERCHANT_ID="m", BT_PUBLIC_KEY="p",
                  BT_PRIVATE_KEY="q", SESSION_COOKIE_SECURE="0", REGISTRAR="fake")
try:
    import braintree  # noqa
except ImportError:
    b = types.ModuleType("braintree")
    b.Configuration = lambda **k: None
    b.Environment = types.SimpleNamespace(Sandbox="sandbox", Production="production")
    b.BraintreeGateway = lambda c: types.SimpleNamespace()
    b.exceptions = types.SimpleNamespace(NotFoundError=type("NF", (Exception,), {}))
    b.Subscription = types.SimpleNamespace(TrialDurationUnit=types.SimpleNamespace(Day="day"))
    sys.modules["braintree"] = b

import app as site, db, repo, billing, worker, registrar as reg
from bt import BraintreeError, Declined

fails = 0
def check(name, cond):
    global fails
    print(("PASS " if cond else "FAIL ") + name); fails += (not cond)

# ---- fake Braintree ----
class FakeBT:
    def __init__(s):
        s.n = itertools.count(1); s.subs = {}; s.decline = False; s.calls = []; s.down = False
        s.gateway = types.SimpleNamespace(webhook_notification=types.SimpleNamespace(verify=lambda ch: "verified-" + ch))
    def client_token(s): return "tok"
    def ensure_customer(s, *a): s.calls.append(("customer", a[0]))
    def add_card(s, cid, nonce):
        if nonce == "declined": raise Declined("Do Not Honor")
        return {"token": "pm-" + nonce, "card_type": "Visa", "last4": "1111", "expiration": "12/2030"}
    def subscribe(s, token, plan_id, price, trial):
        s.calls.append(("subscribe", plan_id, price, trial))
        if s.decline: raise Declined("Insufficient funds")
        if s.down: raise BraintreeError("timeout")
        sid = f"sub{next(s.n)}"
        txs = [] if trial else [{"id": f"tx{next(s.n)}", "status": "submitted_for_settlement", "kind": "sale",
                                 "amount_cents": price, "currency": "USD", "processor_response": "Approved",
                                 "created_at": "2026-11-11 10:00:00"}]
        s.subs[sid] = {"id": sid, "status": "Active", "next_billing_date": "2026-12-11", "transactions": txs}
        return s.subs[sid]
    def find_subscription(s, sid): return s.subs[sid]
    def parse_webhook(s, sig, payload):
        if sig == "bad": raise BraintreeError("bad signature")
        return "subscription_charged_successfully", s.subs[payload]
fbt = FakeBT(); site.bt = fbt

# ---- fake cloud ----
class FakeCloud:
    def __init__(s): s.created = []; s.fail_fip = 0; s.fail_create = False
    def create_openstack_vm(s, name, flavor):
        if s.fail_create: raise RuntimeError("nova down")
        s.created.append((name, flavor)); return "srv-" + name
    def ensure_floating_ip(s, sid, name):
        if s.fail_fip: s.fail_fip -= 1; raise RuntimeError("no router")
        return "192.168.42.77"
cloud = FakeCloud()

app = site.app
runner = app.test_cli_runner()
res = runner.invoke(args=["init-db"])
check("init-db works", res.exit_code == 0 and "6 plans" in res.output)
check("init-db is repeatable", runner.invoke(args=["init-db"]).exit_code == 0)
C = db.connect(os.environ["DATABASE_URL"])
tables = {r["name"] for r in C.all("SELECT name FROM sqlite_master WHERE type='table'")}
check("all tables exist", {"plans","customers","payment_methods","orders","vm_orders","domain_orders",
                           "transactions","braintree_events","godaddy_requests","fake_registry"} <= tables)
schema = open(os.path.join(ROOT, "schema.sql")).read()
check("schema.sql lists the same tables", set(re.findall(r"CREATE TABLE IF NOT EXISTS (\w+)", schema)) == tables - {"sqlite_sequence"})
check("plans seeded with prices", C.one("SELECT price_cents FROM plans WHERE code='domain-eu-annual'")["price_cents"] == 1400)

client = app.test_client()
def csrf():
    client.get("/")
    with client.session_transaction() as s: return s["csrf"]
def _tok(cl):
    with cl.session_transaction() as s: return s["csrf"]
def vm_order(email="ann@example.com", plan="compute-vm-medium", name="box", nonce="n1", cl=None):
    cl = cl or client
    with cl.session_transaction() as s: s.setdefault("csrf", "tk")
    return cl.post("/order", data={"csrf_token": cl.get("/") and _tok(cl), "name": "Ann Lee", "email": email, "vm_name": name,
                                       "plan": plan, "payment_method_nonce": nonce})
def dom_order(label="shop", tld="com", email="ann@example.com", nonce="n2", terms="on"):
    return client.post("/domain/order", data={"csrf_token": csrf(), "name": "Ann Lee", "email": email, "label": label,
                                              "tld": tld, "payment_method_nonce": nonce, "terms": terms})

# ---- VM order ----
r = vm_order()
check("VM order redirects to its status page", r.status_code == 303 and "/order/" in r.headers["Location"])
o = C.one("SELECT * FROM orders WHERE product_type='vm'")
check("VM order is active with Braintree subscription", o["status"] == "active" and o["braintree_subscription_id"] == "sub1")
check("order stores plan price in cents", o["amount_cents"] == 2000 and o["trial_days"] == 30 and o["billing_period"] == "monthly")
v = C.one("SELECT * FROM vm_orders")
check("VM name gets the order id suffix, flavor from plan", v["vm_name"] == "box-" + o["public_id"][:8] and v["flavor"] == "m1.medium")
check("subscribe got price and trial from the database", ("subscribe", "compute-vm-medium", 2000, 30) in fbt.calls)
check("trial order has no charge yet", C.one("SELECT COUNT(*) n FROM transactions")["n"] == 0)
check("card stored as token + last4 only", C.one("SELECT braintree_token, last4 FROM payment_methods") == {"braintree_token": "pm-n1", "last4": "1111"})
check("next billing date stored", o["next_billing_date"] == "2026-12-11")

# ---- several orders, one customer ----
r = dom_order()
check("domain order accepted", r.status_code == 303)
r = vm_order(plan="compute-vm-large", name="big", nonce="n3")
check("customer count stays 1 after 3 orders", C.one("SELECT COUNT(*) n FROM customers")["n"] == 1 and C.one("SELECT COUNT(*) n FROM orders")["n"] == 3)
check("different email is a second customer", vm_order(email="bob@example.com", nonce="n4", cl=app.test_client()).status_code == 303 and C.one("SELECT COUNT(*) n FROM customers")["n"] == 2)
d = C.one("SELECT d.*, o.amount_cents FROM domain_orders d JOIN orders o ON o.id=d.order_id")
check("domain name and price recorded", d["domain_name"] == "shop.com" and d["price_cents"] == 1800 and d["amount_cents"] == 1800 and d["tld"] == "com")
check("domain consent time recorded", re.match(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", d["consent_at"]) is not None)
t = C.one("SELECT * FROM transactions")
check("domain charge stored as transaction", t["amount_cents"] == 1800 and t["kind"] == "sale" and t["braintree_transaction_id"].startswith("tx"))
check("availability check logged", C.one("SELECT COUNT(*) n FROM godaddy_requests WHERE action='availability' AND mode='fake'")["n"] >= 1)

# ---- failures ----
before = C.one("SELECT COUNT(*) n FROM vm_orders")["n"]
fbt.decline = True
r = vm_order(name="nope", nonce="n5")
check("declined payment: 402 and message", r.status_code == 402 and "declined" in r.get_data(as_text=True))
fo = C.one("SELECT * FROM orders WHERE status='failed'")
check("failed order kept with reason, VM row released", fo and "Insufficient funds" in fo["failure_reason"] and C.one("SELECT COUNT(*) n FROM vm_orders")["n"] == before)
r = dom_order(label="lost", nonce="n6")
check("failed domain order frees the name", r.status_code == 402 and C.one("SELECT COUNT(*) n FROM domain_orders WHERE domain_name='lost.com'")["n"] == 0)
fbt.decline = False
r = client.post("/order", data={"csrf_token": csrf(), "name": "A", "email": "x", "vm_name": "box", "plan": "compute-vm-basic", "payment_method_nonce": "declined"})
check("bad form rejected", r.status_code == 400)
r = vm_order(nonce="declined", name="cardbad")
check("card refused at vault: 402, no order row", r.status_code == 402 and C.one("SELECT COUNT(*) n FROM orders WHERE plan_code='compute-vm-medium' AND status='pending'")["n"] == 0)
fbt.down = True
r = vm_order(name="down1", nonce="n7")
check("Braintree outage: 502, order marked failed", r.status_code == 502 and C.one("SELECT status s FROM orders ORDER BY id DESC LIMIT 1")["s"] == "failed")
fbt.down = False

# ---- domain name rules ----
client.get("/domain")
with client.session_transaction() as s: tk = s["csrf"]
def search(label, tld="com"): return client.post("/domain/search", data={"csrf_token": tk, "label": label, "tld": tld})
check("free name offered", "is available" in search("fresh").get_data(as_text=True))
check("name ordered by someone is taken", "already taken" in search("shop").get_data(as_text=True))
check("fake registry reserved name is taken", "already taken" in search("google").get_data(as_text=True))
check("unsupported extension refused", search("fresh", "org").status_code == 400)
check("second order for same domain refused", dom_order(label="shop", nonce="n8").status_code in (200, 409))
site_domain_available = site.domain_available
site.domain_available = lambda d: (True, None)
calls_before = len([c for c in fbt.calls if c[0] == "subscribe"])
r = dom_order(label="shop", nonce="n9")
check("race on the same domain: 409 and no charge", r.status_code == 409 and len([c for c in fbt.calls if c[0] == "subscribe"]) == calls_before)
site.domain_available = site_domain_available
check("domain terms required", dom_order(label="fresh", terms="").status_code == 400)

# ---- status pages ----
pid = C.one("SELECT public_id FROM orders WHERE product_type='vm' ORDER BY id")["public_id"]
h = client.get(f"/order/{pid}").get_data(as_text=True)
check("status page shows VM in progress", "Creating your VM" in h and "box-" in h and "$20 per month" in h)
check("unknown order is 404", client.get("/order/" + "0" * 8 + "-0000-0000-0000-" + "0" * 12).status_code == 404 and client.get("/order/zzz").status_code == 404)
h = client.get("/orders").get_data(as_text=True)
check("My orders lists this customer's orders", "shop.com" in h and "box-" in h and "big-" in h and "bob" not in h)
check("My orders is empty without a session", "haven't ordered" in app.test_client().get("/orders").get_data(as_text=True))

# ---- worker ----
registry = reg.FakeRegistrar(C, taken="google")
worker.run_once(C, cloud, registry)
vm = C.one("SELECT * FROM vm_orders WHERE vm_name LIKE 'box-%'")
check("worker boots VM with plan flavor and records server + IP", vm["openstack_server_id"] and vm["floating_ip"] == "192.168.42.77" and ("box-" + o["public_id"][:8], "m1.medium") in cloud.created)
check("VM order marked done", C.one("SELECT fulfillment_status s FROM orders WHERE id=%s", (o["id"],))["s"] == "done")
dd = C.one("SELECT * FROM domain_orders WHERE domain_name='shop.com'")
check("worker registered the domain (fake)", dd["registrar"] == "fake" and dd["registrar_registration_id"].startswith("fake-") and dd["years_paid"] == 1 and dd["registrar_cost_cents"] == 1199)
check("expiry about a year out", dd["expires_at"] > "2027-")
check("fake registry row exists", C.one("SELECT COUNT(*) n FROM fake_registry WHERE domain_name='shop.com'")["n"] == 1)
acts = [r["action"] for r in C.all("SELECT action FROM godaddy_requests WHERE order_id=%s ORDER BY id", (dd["order_id"],))]
check("registrar log has availability, register, auto_renew_off", acts == ["availability", "register", "auto_renew_off"])
n_created = len(cloud.created)
worker.run_once(C, cloud, registry)
check("second pass does nothing", len(cloud.created) == n_created and C.one("SELECT COUNT(*) n FROM godaddy_requests WHERE action='register'")["n"] == 1)
h = client.get(f"/order/{pid}").get_data(as_text=True)
check("status page shows IP when ready", "Your VM is ready" in h and "192.168.42.77" in h)
dpid = C.one("SELECT public_id FROM orders WHERE product_type='domain'")["public_id"]
h = client.get(f"/order/{dpid}").get_data(as_text=True)
check("domain status shows registered + expiry + payment", "shop.com is registered" in h and "Registered until" in h and "$18" in h)

# domain is not bought before the charge exists
t_id = C.one("SELECT id FROM orders WHERE product_type='domain'")["id"]
c2 = repo.get_or_create_customer(C, "Ann Lee", "ann@example.com")[0]
oid, _ = repo.create_order(C, c2["id"], repo.domain_plan_for_tld(C, "net"), None, domain="late.net", consent_at=db.now())
C.execute("UPDATE orders SET status='active' WHERE id=%s", (oid,)); C.commit()
worker.run_once(C, cloud, registry)
check("no charge yet: domain not registered", C.one("SELECT fulfillment_status s FROM orders WHERE id=%s", (oid,))["s"] == "pending" and C.one("SELECT COUNT(*) n FROM fake_registry WHERE domain_name='late.net'")["n"] == 0)

# renewal
sub = fbt.subs[C.one("SELECT braintree_subscription_id s FROM orders WHERE id=%s", (t_id,))["s"]]
sub["transactions"].append({"id": "tx-renew", "status": "settled", "kind": "sale", "amount_cents": 1800, "currency": "USD", "processor_response": "Approved", "created_at": "2027-11-11 10:00:00"})
billing.apply_subscription(C, sub)
worker.run_once(C, cloud, registry)
dd2 = C.one("SELECT * FROM domain_orders WHERE domain_name='shop.com'")
check("second yearly charge renews the domain once", dd2["years_paid"] == 2 and dd2["expires_at"] > dd["expires_at"])
worker.run_once(C, cloud, registry)
check("no double renewal", C.one("SELECT years_paid y FROM domain_orders WHERE domain_name='shop.com'")["y"] == 2 and C.one("SELECT COUNT(*) n FROM godaddy_requests WHERE action='renew'")["n"] == 1)
billing.apply_subscription(C, sub)
check("repeated transactions are stored once", C.one("SELECT COUNT(*) n FROM transactions WHERE braintree_transaction_id='tx-renew'")["n"] == 1)

# retries
r = vm_order(name="flaky", nonce="n10")
cloud.fail_fip = 1
worker.run_once(C, cloud, registry)
fo = C.one("SELECT o.*, v.openstack_server_id FROM orders o JOIN vm_orders v ON v.order_id=o.id WHERE v.vm_name LIKE 'flaky-%'")
check("transient failure: pending again, attempt counted, server id kept", fo["fulfillment_status"] == "pending" and fo["fulfillment_attempts"] == 1 and fo["openstack_server_id"])
before = len(cloud.created)
worker.run_once(C, cloud, registry)
check("retry reuses the VM and finishes", len(cloud.created) == before and C.one("SELECT fulfillment_status s FROM orders WHERE id=%s", (fo["id"],))["s"] == "done")
r = vm_order(name="doomed", nonce="n11"); cloud.fail_create = True
for _ in range(worker.MAX_ATTEMPTS): worker.run_once(C, cloud, registry)
check("after MAX_ATTEMPTS the order needs review", C.one("SELECT fulfillment_status s, fulfillment_error e FROM orders ORDER BY id DESC LIMIT 1") == {"s": "needs_review", "e": "nova down"})
cloud.fail_create = False
check("claim only succeeds once", (lambda i: (worker.claim(C, i), worker.claim(C, i)))(oid) in ((False, False), (True, False)))

# domain taken at the registrar meanwhile
r = dom_order(label="ghost", nonce="n12")
C.insert("INSERT INTO fake_registry (domain_name, registration_id, cost_cents, registered_at, expires_at) VALUES ('ghost.com','x',1,'2026-01-01 00:00:00','2027-01-01')")
C.commit(); worker.run_once(C, cloud, registry)
check("domain lost at the registrar: needs_review, no retry", C.one("SELECT fulfillment_status s FROM orders o JOIN domain_orders d ON d.order_id=o.id WHERE d.domain_name='ghost.com'")["s"] == "needs_review")

# sync and webhook
sid = C.one("SELECT braintree_subscription_id s FROM orders WHERE id=%s", (o["id"],))["s"]
fbt.subs[sid]["status"] = "Past Due"
worker.sync_braintree(C, fbt)
check("sync: Past Due recorded", C.one("SELECT status s FROM orders WHERE id=%s", (o["id"],))["s"] == "past_due")
fbt.subs[sid]["status"] = "Canceled"
r = app.test_client().post("/braintree/webhook", data={"bt_signature": "sig", "bt_payload": sid})
check("webhook cancels the order", r.status_code == 200 and C.one("SELECT status s, cancelled_at c FROM orders WHERE id=%s", (o["id"],))["s"] == "cancelled")
r2 = app.test_client().post("/braintree/webhook", data={"bt_signature": "sig", "bt_payload": sid})
check("same webhook twice is ignored", r2.get_data(as_text=True) == "duplicate")
check("bad signature rejected", app.test_client().post("/braintree/webhook", data={"bt_signature": "bad", "bt_payload": "x"}).status_code == 400)
check("webhook challenge answered", app.test_client().get("/braintree/webhook?bt_challenge=abc").get_data(as_text=True) == "verified-abc")
check("cancelled order page", "not active" in client.get(f"/order/{pid}").get_data(as_text=True))

# webhook retry: a failure while applying must not swallow the notification
sid2 = C.one("SELECT braintree_subscription_id s FROM orders WHERE plan_code='compute-vm-large'")["s"]
good = billing.apply_subscription
def boom(*a): raise RuntimeError("db hiccup")
billing.apply_subscription = boom
r = app.test_client().post("/braintree/webhook", data={"bt_signature": "sig", "bt_payload": sid2})
billing.apply_subscription = good
check("apply failure -> 500 and event not remembered", r.status_code == 500 and C.one("SELECT COUNT(*) n FROM braintree_events WHERE subscription_id=%s", (sid2,))["n"] == 0)
r = app.test_client().post("/braintree/webhook", data={"bt_signature": "sig", "bt_payload": sid2})
check("Braintree's retry is then processed", r.status_code == 200 and r.get_data(as_text=True) == "ok" and C.one("SELECT COUNT(*) n FROM braintree_events WHERE subscription_id=%s", (sid2,))["n"] == 1)
fbt.subs["webhook-selftest"] = {"id": "webhook-selftest", "status": "Active", "next_billing_date": None, "transactions": []}
fbt.gateway.webhook_testing = types.SimpleNamespace(sample_notification=lambda kind, i: {"bt_signature": "sig-" + kind, "bt_payload": i})
sent = {}
def fake_post(url, data, timeout):
    sent.update(url=url, data=data)
    resp = app.test_client().post("/braintree/webhook", data=data)
    return types.SimpleNamespace(status_code=resp.status_code, text=resp.get_data(as_text=True))
site.requests.post = fake_post
res = runner.invoke(args=["webhook-test", "https://x.ngrok-free.app/braintree/webhook"])
check("webhook-test sends a signed sample and reports 200", res.exit_code == 0 and "200 ok" in res.output and sent["data"]["bt_payload"] == "webhook-selftest")
check("sample webhook for unknown subscription changes no order", C.one("SELECT error e FROM braintree_events WHERE subscription_id='webhook-selftest'")["e"] == "no order for this subscription")

# integrity
try:
    C.insert("INSERT INTO orders (public_id, customer_id, plan_code, product_type, amount_cents, billing_period, created_at, updated_at) VALUES ('p',999,'compute-vm-basic','vm',1,'monthly','x','x')")
    ok = False
except db.IntegrityError:
    ok = True
check("foreign keys enforced", ok)
res = runner.invoke(args=["orders", "ann@example.com"])
check("orders CLI lists the customer's orders", res.exit_code == 0 and "shop.com" in res.output and res.output.count("\n") >= 5)
check("healthz", app.test_client().get("/healthz").data == b"ok")
from plans import money
check("money formatting", money(1800) == "$18" and money(1850) == "$18.50" and money(5) == "$0.05")
os.remove(DBFILE)
print("FAILED" if fails else "ALL PASS"); sys.exit(1 if fails else 0)
