"""
Small database layer. MariaDB in production (pymysql), SQLite for the tests.

Queries use %s placeholders and portable SQL. Times are passed in as UTC
strings from now(), so both back ends store the same thing.
"""

import re
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timezone
from urllib.parse import unquote, urlparse


class IntegrityError(Exception):
    """A unique or foreign key rule was broken."""


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def _plain(value):
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    return value


class Conn:
    def __init__(self, raw, kind):
        self.raw, self.kind = raw, kind

    def _sql(self, sql):
        return sql.replace("%s", "?") if self.kind == "sqlite" else sql

    def _run(self, sql, params):
        cur = self.raw.cursor()
        try:
            cur.execute(self._sql(sql), tuple(params))
        except (sqlite3.IntegrityError, *_pymysql_integrity()) as exc:
            cur.close()
            raise IntegrityError(str(exc)) from exc
        return cur

    def all(self, sql, params=()):
        cur = self._run(sql, params)
        try:
            rows = cur.fetchall()
            names = [d[0] for d in cur.description]
        finally:
            cur.close()
        return [{n: _plain(v) for n, v in zip(names, tuple(r))} for r in rows]

    def one(self, sql, params=()):
        rows = self.all(sql, params)
        return rows[0] if rows else None

    def execute(self, sql, params=()):
        """Returns the number of rows changed."""
        cur = self._run(sql, params)
        try:
            return cur.rowcount
        finally:
            cur.close()

    def insert(self, sql, params=()):
        """Returns the new auto-increment id."""
        cur = self._run(sql, params)
        try:
            return cur.lastrowid
        finally:
            cur.close()

    def commit(self):
        self.raw.commit()

    def rollback(self):
        self.raw.rollback()

    def close(self):
        self.raw.close()

    @contextmanager
    def tx(self):
        """Commit on success, roll back on any error."""
        try:
            yield self
            self.commit()
        except BaseException:
            self.rollback()
            raise


def _pymysql_integrity():
    try:
        import pymysql.err
        return (pymysql.err.IntegrityError,)
    except ImportError:
        return ()


def connect(url: str) -> Conn:
    """url: mysql://user:password@host:3306/dbname   or   sqlite:///path/to.db"""
    parsed = urlparse(url)
    if parsed.scheme == "sqlite":
        # Python opens a transaction at the first write and ends it at commit()/rollback(),
        # so plain reads never hold a lock.
        raw = sqlite3.connect(parsed.path[1:] or ":memory:", timeout=5)
        raw.execute("PRAGMA foreign_keys = ON")
        return Conn(raw, "sqlite")
    if parsed.scheme in ("mysql", "mariadb", "mysql+pymysql"):
        import pymysql
        raw = pymysql.connect(
            host=parsed.hostname or "127.0.0.1",
            port=parsed.port or 3306,
            user=unquote(parsed.username or ""),
            password=unquote(parsed.password or ""),
            database=parsed.path.lstrip("/"),
            charset="utf8mb4",
            autocommit=False,
            connect_timeout=10,
        )
        return Conn(raw, "mysql")
    raise ValueError("DATABASE_URL must start with mysql:// or sqlite:///")


def sqlite_schema(mariadb_sql: str) -> str:
    """Turns schema.sql into SQLite syntax. Used only by the tests."""
    out = []
    for line in mariadb_sql.splitlines():
        s = line.strip()
        if re.match(r"^(KEY|INDEX)\b", s):
            continue
        s = re.sub(r"^UNIQUE KEY \w+ ", "UNIQUE ", s)
        s = re.sub(r"\) ENGINE=.*;", ");", s)
        s = re.sub(r"ENUM\([^)]*\)", "TEXT", s)
        s = re.sub(r"\b(BIGINT|SMALLINT|TINYINT|INT)( UNSIGNED)?(\(\d+\))?", "INTEGER", s)
        s = s.replace("AUTO_INCREMENT", "")
        out.append(s)
    text = "\n".join(out)
    # a trailing comma before ")" is left behind where KEY lines were removed
    return re.sub(r",\s*\n\)", "\n)", text)
