#!/usr/bin/env python3
"""
Fulfilment worker. Runs on the OpenStack controller (it needs the OpenStack API
and the order database; it also works with REGISTRAR=fake on the same machine).

Every pass:
  1. frees orders left 'in_progress' by a crashed worker
  2. boots VMs (+ floating IP) for paid VM orders
  3. registers domains for paid domain orders
  4. renews domains whose subscription was charged again
  5. every SYNC_INTERVAL seconds, asks Braintree for the state of live subscriptions
     (this is what picks up renewals, failed charges and cancellations when
     Braintree's webhooks cannot reach this lab)

Run:  python worker.py          (loop)      python worker.py --once   (one pass)
Environment: see worker.env.example
"""

import logging
import os
import sys
import time

import billing
import db
import repo
from registrar import LoggedRegistrar, RegistrarError, make_registrar

log = logging.getLogger("worker")
MAX_ATTEMPTS = int(os.environ.get("MAX_ATTEMPTS", "5"))
STALE_MINUTES = 15


class Permanent(Exception):
    """Retrying will not help; a person has to look at the order."""


def release_stale(c):
    cutoff = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(time.time() - STALE_MINUTES * 60))
    n = c.execute("UPDATE orders SET fulfillment_status='pending' "
                  "WHERE fulfillment_status='in_progress' AND updated_at < %s", (cutoff,))
    c.commit()
    if n:
        log.warning("Released %s stuck order(s)", n)


def claim(c, order_id):
    n = c.execute("UPDATE orders SET fulfillment_status='in_progress', updated_at=%s "
                  "WHERE id=%s AND fulfillment_status='pending'", (db.now(), order_id))
    c.commit()
    return n == 1


def finish(c, order_id, state, error=None):
    attempts = ", fulfillment_attempts = fulfillment_attempts + 1" if state == "pending" else ""
    c.execute(f"UPDATE orders SET fulfillment_status=%s, fulfillment_error=%s, updated_at=%s{attempts} "
              "WHERE id=%s", (state, (error or "")[:255] or None, db.now(), order_id))
    c.commit()


def fulfill_vm(c, order, cloud):
    server_id = order["openstack_server_id"]
    if not server_id:
        server_id = cloud.create_openstack_vm(order["vm_name"], order["flavor"])
        c.execute("UPDATE vm_orders SET openstack_server_id=%s WHERE order_id=%s", (server_id, order["id"]))
        c.commit()  # recorded at once: a retry reuses the VM instead of booting a second one
    ip = cloud.ensure_floating_ip(server_id, order["vm_name"])
    c.execute("UPDATE vm_orders SET floating_ip=%s WHERE order_id=%s", (ip, order["id"]))
    c.commit()


def fulfill_domain(c, order, registrar):
    reg = LoggedRegistrar(registrar, c, order["id"])
    domain = order["domain_name"]
    key = f"order-{order['public_id']}"
    info = reg.owns(domain, key)  # a crashed earlier attempt of this same order already bought it
    if not info:
        if not reg.check(domain)["available"]:
            raise Permanent(f"{domain} is no longer available")
        consent = c.one("SELECT consent_at FROM domain_orders WHERE order_id=%s", (order["id"],))["consent_at"]
        info = reg.register(domain, consent, key)
    try:
        reg.set_auto_renew_off(domain)  # we bill and renew; the registrar must not also
    except RegistrarError as exc:
        log.warning("Could not switch off auto-renew for %s: %s", domain, exc)
    c.execute(
        "UPDATE domain_orders SET registrar=%s, registrar_registration_id=%s, registrar_cost_cents=%s, "
        "registered_at=%s, expires_at=%s, years_paid=1, auto_renew=0 WHERE order_id=%s",
        ("fake" if registrar.mode == "fake" else "godaddy", info["registration_id"], info["cost_cents"],
         info["registered_at"], info["expires_at"], order["id"]))
    c.commit()


def process_pending(c, cloud, registrar):
    rows = c.all("SELECT id FROM orders WHERE status='active' AND fulfillment_status='pending' ORDER BY id")
    for row in rows:
        order = repo.get_order(c, row["id"])
        if order["product_type"] == "domain" and repo.successful_sales(c, order["id"]) < 1:
            continue  # the charge has not gone through yet; nothing is bought before it does
        if not claim(c, order["id"]):
            continue
        try:
            if order["product_type"] == "vm":
                fulfill_vm(c, order, cloud)
            else:
                fulfill_domain(c, order, registrar)
            finish(c, order["id"], "done")
            log.info("Order %s fulfilled", order["public_id"])
        except Permanent as exc:
            log.error("Order %s needs review: %s", order["public_id"], exc)
            finish(c, order["id"], "needs_review", str(exc))
        except Exception as exc:  # noqa: BLE001
            transient = getattr(exc, "transient", True)
            log.exception("Order %s failed (attempt %s)", order["public_id"], order["fulfillment_attempts"] + 1)
            if not transient or order["fulfillment_attempts"] + 1 >= MAX_ATTEMPTS:
                finish(c, order["id"], "needs_review", str(exc))
            else:
                finish(c, order["id"], "pending", str(exc))


def renew_domains(c, registrar):
    rows = c.all("SELECT o.id FROM orders o JOIN domain_orders d ON d.order_id = o.id "
                 "WHERE o.status='active' AND o.fulfillment_status='done' AND d.years_paid > 0")
    for row in rows:
        order = repo.get_order(c, row["id"])
        if repo.successful_sales(c, order["id"]) <= order["years_paid"]:
            continue
        reg = LoggedRegistrar(registrar, c, order["id"])
        try:
            result = reg.renew(order["domain_name"])
        except RegistrarError as exc:
            log.error("Renewal of %s failed: %s", order["domain_name"], exc)
            if not exc.transient:
                finish(c, order["id"], "needs_review", str(exc))
            continue
        c.execute("UPDATE domain_orders SET years_paid = years_paid + 1, expires_at=%s WHERE order_id=%s",
                  (result["expires_at"], order["id"]))
        c.commit()
        log.info("Renewed %s until %s", order["domain_name"], result["expires_at"])


def sync_braintree(c, bt):
    rows = c.all("SELECT braintree_subscription_id AS sid FROM orders "
                 "WHERE braintree_subscription_id IS NOT NULL AND status IN ('active','past_due')")
    for row in rows:
        try:
            billing.apply_subscription(c, bt.find_subscription(row["sid"]))
        except Exception as exc:  # noqa: BLE001
            log.error("Sync of %s failed: %s", row["sid"], exc)


def run_once(c, cloud, registrar, bt=None, sync=False):
    release_stale(c)
    if sync and bt is not None:
        sync_braintree(c, bt)
    process_pending(c, cloud, registrar)
    renew_domains(c, registrar)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    import cloud
    bt = None
    if os.environ.get("BT_MERCHANT_ID"):
        from bt import Braintree
        bt = Braintree(os.environ.get("BT_ENVIRONMENT", "sandbox"), os.environ["BT_MERCHANT_ID"],
                       os.environ["BT_PUBLIC_KEY"], os.environ["BT_PRIVATE_KEY"])
    interval = float(os.environ.get("POLL_SECONDS", "10"))
    sync_every = float(os.environ.get("SYNC_INTERVAL", "300"))
    last_sync = 0.0
    once = "--once" in sys.argv
    while True:
        c = None
        try:
            c = db.connect(os.environ["DATABASE_URL"])
            do_sync = time.time() - last_sync >= sync_every
            run_once(c, cloud, make_registrar(c), bt, sync=do_sync or once)
            if do_sync:
                last_sync = time.time()
        except Exception:  # noqa: BLE001
            log.exception("Worker pass failed")
        finally:
            if c is not None:
                c.close()
        if once:
            return
        time.sleep(interval)


if __name__ == "__main__":
    main()
