"""
GoDaddy Domains API client.

Uses the v3 register flow (availability check, price-locked quote, idempotent
registration that is polled until it finishes) plus the few stable v1 calls
the v3 API still leaves there (read a domain, switch auto-renew off, renew).

Authentication is a Personal Access Token (Bearer). The site needs only the
read scope (domains.domain:read). The webhook listener needs
domains.domain:create and domains.domain:update as well, so give each its own
token.

v3 registers the domain under the registrant contact and the payment method
stored on the GoDaddy account that owns the token. The customer is not
entered as registrant.

Nothing here talks to Kill Bill. This file is shared by the order site and the
webhook listener: keep the two copies identical.
"""

import re
import time

import requests

DEFAULT_BASE_URL = "https://api.godaddy.com"

# One DNS label: 1 to 63 letters, digits or hyphens, no leading or trailing
# hyphen, and no "--" in positions 3 and 4 (that is the punycode prefix).
_LABEL_RE = re.compile(r"^(?!..--)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
_DOMAIN_RE = re.compile(r"^(?!..--)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.[a-z]{2,24}$")


class GoDaddyError(Exception):
    """transient=True means a retry later can succeed (network, 429, 5xx)."""

    def __init__(self, message, status=None, code=None, body=None, transient=False):
        super().__init__(message)
        self.status = status
        self.code = code
        self.body = body
        self.transient = transient


class GoDaddyPending(GoDaddyError):
    """The registration is still running. Poll again later; never resubmit."""

    def __init__(self, message):
        super().__init__(message, transient=True)


def normalize_label(raw, tld=None):
    """'  Example.COM ' -> 'example' when tld is 'com'. Returns '' when unusable."""
    value = (raw or "").strip().lower().replace(" ", "")
    if tld and value.endswith("." + tld):
        value = value[: -(len(tld) + 1)]
    return value


def valid_label(label):
    return bool(_LABEL_RE.match(label or ""))


def valid_domain(domain):
    return bool(_DOMAIN_RE.match(domain or ""))


def _money(obj):
    """{'currencyCode': 'USD', 'value': 1199} -> (1199, 'USD'); values are minor units."""
    if not isinstance(obj, dict):
        return None, None
    try:
        return int(obj.get("value")), obj.get("currencyCode")
    except (TypeError, ValueError):
        return None, obj.get("currencyCode")


def _error_details(resp):
    try:
        data = resp.json()
    except ValueError:
        return None, None
    if isinstance(data, dict):
        return data.get("code"), data.get("message")
    return None, None


class GoDaddy:
    def __init__(self, token, base_url=DEFAULT_BASE_URL, timeout=20):
        if not token:
            raise ValueError("A GoDaddy token is required")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "User-Agent": "kb-order-site",
        })

    # ---- plumbing ----
    def _request(self, method, path, **kwargs):
        url = f"{self.base_url}{path}"
        try:
            resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        except requests.RequestException as exc:
            raise GoDaddyError(f"Cannot reach GoDaddy: {exc}", transient=True) from exc
        if resp.status_code >= 400:
            code, message = _error_details(resp)
            raise GoDaddyError(
                f"{method} {path} failed with HTTP {resp.status_code}"
                + (f" ({code})" if code else "")
                + (f": {message}" if message else ""),
                status=resp.status_code,
                code=code,
                body=(resp.text or "")[:500],
                transient=resp.status_code == 429 or resp.status_code >= 500,
            )
        return resp

    # ---- availability and quote (read only, no charge) ----
    def check_availability(self, domain, accurate=True):
        params = {"domain": domain}
        if accurate:
            params["optimizeFor"] = "ACCURACY"  # live registry check instead of cached
        data = self._request("GET", "/v3/domains/check-availability", params=params).json()
        price_cents, currency = None, None
        for entry in data.get("prices") or []:
            if entry.get("period", 1) == 1:
                price_cents, currency = _money(entry.get("price"))
                break
        return {
            "domain": data.get("domain", domain),
            "available": bool(data.get("available")),
            "definitive": bool(data.get("definitive", True)),
            "price_cents": price_cents,
            "currency": currency,
        }

    def quote(self, domain, period=1):
        data = self._request(
            "POST", "/v3/domains/registration-quotes", json={"domain": domain, "period": period}
        ).json()
        items = data.get("items") or []
        item = next((i for i in items if str(i.get("domain", "")).lower() == domain.lower()),
                    items[0] if items else None)
        if not data.get("quoteToken") or not item:
            raise GoDaddyError("GoDaddy returned a quote without a token or price")
        price_cents, currency = _money(item.get("price"))
        if price_cents is None:
            raise GoDaddyError("GoDaddy returned a quote without a price")
        return {
            "token": data["quoteToken"],
            "expires_at": data.get("expiresAt"),
            "price_cents": price_cents,
            "currency": currency,
            "fees": item.get("fees") or [],
            "agreements": [
                {"type": a.get("agreementType"), "title": a.get("title") or a.get("agreementType"),
                 "url": a.get("url")}
                for a in data.get("requiredAgreements") or []
                if a.get("agreementType")
            ],
        }

    # ---- registration (charges the GoDaddy account) ----
    def register(self, quote, domain, period, agreed_at, agreement_types, idempotency_key):
        """Starts the registration and returns its id. Always sends an idempotency key."""
        consent = {"agreedAt": agreed_at, "agreementTypes": list(agreement_types)}
        if quote.get("fees"):
            consent["acknowledgedFees"] = quote["fees"]
        resp = self._request(
            "POST",
            "/v3/domains/registrations",
            headers={"Idempotency-Key": str(idempotency_key)},
            json={"quoteToken": quote["token"], "domain": domain, "period": period, "consent": consent},
        )
        data = resp.json() if resp.content else {}
        registration_id = data.get("registrationId") or data.get("operationId") or data.get("id")
        if not registration_id:
            location = resp.headers.get("Location", "")
            registration_id = location.rstrip("/").split("/")[-1] if location else None
        if not registration_id:
            raise GoDaddyError("GoDaddy accepted the registration but returned no id")
        return str(registration_id)

    def get_registration(self, registration_id):
        return self._request("GET", f"/v3/domains/registrations/{registration_id}").json()

    def wait_for_registration(self, registration_id, timeout=120, interval=3, sleep=time.sleep):
        """Returns the completed registration, raises on FAILED, GoDaddyPending on timeout."""
        deadline = time.monotonic() + timeout
        while True:
            data = self.get_registration(registration_id)
            status = str(data.get("status", "")).upper()
            if status == "COMPLETED":
                return data
            if status == "FAILED":
                reason = data.get("failureReason") or data.get("error") or data.get("message") or ""
                raise GoDaddyError(
                    f"Registration {registration_id} failed" + (f": {reason}" if reason else ""),
                    code="REGISTRATION_FAILED",
                )
            if time.monotonic() >= deadline:
                raise GoDaddyPending(
                    f"Registration {registration_id} is still {status or 'running'}"
                )
            sleep(interval)

    # ---- stable v1 calls ----
    def get_domain(self, domain):
        """The domain's record on this account, or None if the account doesn't own it."""
        try:
            return self._request("GET", f"/v1/domains/{domain}").json()
        except GoDaddyError as exc:
            if exc.status == 404:
                return None
            raise

    def set_auto_renew(self, domain, enabled):
        self._request("PATCH", f"/v1/domains/{domain}", json={"renewAuto": bool(enabled)})

    def renew(self, domain, period=1):
        """Charges the account's billing method. Not idempotent: check `expires` before retrying."""
        resp = self._request("POST", f"/v1/domains/{domain}/renew", json={"period": period})
        return resp.json() if resp.content else {}
