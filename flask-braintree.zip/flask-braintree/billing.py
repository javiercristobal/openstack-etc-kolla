"""Applies Braintree's view of a subscription to our orders. Used by the site, the
webhook endpoint and the worker's periodic sync, so all three behave the same."""

import repo
from db import now

STATUS_MAP = {
    "Active": "active",
    "Pending": "active",
    "Past Due": "past_due",
    "Canceled": "cancelled",
    "Expired": "cancelled",
}


def apply_subscription(c, sub):
    """Stores the subscription's transactions and status. Returns the order id, or None
    if no order has this subscription."""
    order = c.one("SELECT * FROM orders WHERE braintree_subscription_id = %s", (sub["id"],))
    if not order:
        return None
    repo.record_transactions(c, order, sub["transactions"])
    status = STATUS_MAP.get(sub["status"], order["status"])
    if order["status"] == "failed":
        status = "failed"
    cancelled_at = now() if status == "cancelled" and not order["cancelled_at"] else order["cancelled_at"]
    c.execute(
        "UPDATE orders SET status=%s, next_billing_date=%s, cancelled_at=%s, updated_at=%s WHERE id=%s",
        (status, sub["next_billing_date"], cancelled_at, now(), order["id"]),
    )
    c.commit()
    return order["id"]
