# flask-braintree: VM and domain orders, Braintree billing, MariaDB

Customers order a VM (3 plans) or a domain (.com, .net, .eu) on the site and pay through
Braintree. Everything is stored in MariaDB. `worker.py` on the OpenStack controller reads
paid orders from the same database and creates the VM or registers the domain.
Kill Bill is no longer used.

    customer -> site (Flask) -> Braintree subscription
                    |                    ^
                    v                    | sync every 5 min (and webhooks, if reachable)
                 MariaDB <------------ worker.py (controller) -> OpenStack
                                              \-> registrar: fake (table) or GoDaddy

## The tables

One customer has many orders. An order is one subscription: one VM or one domain.

    customers 1──* payment_methods
        │1
        *
     orders *──1 plans
        │1  ├── 0..1 vm_orders        (product_type = 'vm')
        │   ├── 0..1 domain_orders    (product_type = 'domain')
        *   ├── * godaddy_requests
   transactions

| Table | What it holds |
|---|---|
| `plans` | The catalogue: code, VM or domain, price in cents, monthly or yearly, trial days, the Braintree plan id, the OpenStack flavor (VMs) or extension (domains). The site reads prices from here. |
| `customers` | One row per person (unique email) and their Braintree customer id. |
| `payment_methods` | Cards in the Braintree vault: token, card type, last 4 digits, expiry. Never the card number. |
| `orders` | One row per order: customer, plan, status (`pending`, `active`, `past_due`, `cancelled`, `failed`), fulfilment status (`pending`, `in_progress`, `done`, `failed`, `needs_review`), price and currency, billing period, Braintree subscription id, next billing date, failure reason. |
| `vm_orders` | VM name, flavor, OpenStack server id, floating IP. |
| `domain_orders` | Domain name (unique), extension, **price charged to the customer**, consent time, registrar (`fake` or `godaddy`), registrar registration id, **registrar cost**, registered date, expiry date, years paid. |
| `transactions` | Every Braintree charge and refund: Braintree transaction id (unique), amount, status, date. |
| `godaddy_requests` | Log of every registrar call (availability, register, renew, auto-renew off): domain, order, mode, result, cost. |
| `fake_registry` | The stand-in registry used while `REGISTRAR=fake`: the domains the fake GoDaddy has "registered". |
| `braintree_events` | Webhook notifications received (hash is unique, so repeats are ignored). |

The full MariaDB definition is `schema.sql` (InnoDB, utf8mb4, money in cents, times in UTC).

## Fake GoDaddy

With `REGISTRAR=fake` (the default) nothing leaves the machine. Availability and registration
use `fake_registry`. These names always count as taken: google, example, taken, test, amazon
(change with `FAKE_TAKEN_NAMES`). The fake "wholesale" costs are .com $11.99, .net $13.99, .eu $8.99,
recorded in `domain_orders.registrar_cost_cents` next to the price the customer paid.
Set `REGISTRAR=godaddy` and `GODADDY_TOKEN` in `/etc/kb-worker.env` and `/etc/kb-order.env`
to use the real API (`godaddy.py`), with the same calls and the same tables.

## How an order flows

1. The site saves the customer (by email), the card in Braintree's vault, and an `orders` row.
2. It creates a Braintree subscription with the plan, the price from `plans`, and the trial (VMs: 30 days).
   Domains have no trial, so the first charge happens now. If Braintree declines, the order is marked
   `failed` and the VM name or domain is freed.
3. The worker sees `status = active` + `fulfillment_status = pending` and boots the VM and attaches the floating IP,
   or registers the domain. A domain is never registered before its first charge appears in `transactions`.
4. Each yearly charge of a domain subscription renews the domain once. A failed attempt retries
   up to 5 times, then becomes `needs_review`.

## Deploy

I could not deploy this: I have no access to your servers. You run the scripts.

1. **Braintree plans.** In the sandbox control panel (Recurring Billing > Plans) create six plans with
   these exact IDs: `compute-vm-basic`, `compute-vm-medium`, `compute-vm-large` (billing every 1 month) and
   `domain-com-annual`, `domain-net-annual`, `domain-eu-annual` (billing every 12 months). The price and
   trial of each order are sent by the site, so the plan's own price does not matter.
2. **MariaDB on the Flask VM.** `sudo mariadb < deploy/mariadb-setup.sql` (change the passwords and the
   controller's address in it), set `bind-address = 0.0.0.0` in the MariaDB config so the controller can connect,
   then `mariadb flask_orders < schema.sql`.
3. **Site (Flask VM).** Fill `/etc/kb-order.env` (`deploy/kb-order.env.example`), then
   `sudo bash scripts/install-site.sh`. It creates the plans, checks Braintree and starts `kb-order`.
   Your existing nginx config keeps working (`deploy/nginx.conf` is the same as before).
4. **Worker (controller).** Fill `/etc/kb-worker.env` (`deploy/worker.env.example`), then
   `sudo bash scripts/install-worker.sh`. It stops the old `kb-webhook` service and starts `kb-worker`.
   Watch it with `sudo journalctl -u kb-worker -f`.
5. Check: place a VM order and a domain order, then run `flask --app app orders you@example.com`
   or look at the tables.

## Webhooks through ngrok

Braintree can only call a public HTTPS address, so ngrok forwards one path of the site to the lab.
Only `/braintree/webhook` is reachable from the internet; every other path gets a 404 from ngrok.

1. Install the ngrok agent on the Flask VM (https://ngrok.com/download) and note your authtoken and your
   domain (ngrok dashboard > Domains; the free plan includes one).
2. `sudo bash scripts/setup-ngrok.sh`. The first run copies `deploy/ngrok.yml` to `/etc/ngrok/ngrok.yml`;
   edit it (authtoken, domain) and run the script again. It checks the config, starts the `ngrok` service
   and prints the webhook URL.
3. Check the tunnel end to end, from the Flask VM:
   `cd /opt/flask-killbill && sudo -u www-data bash -c 'set -a; . /etc/kb-order.env; set +a; venv/bin/flask --app app webhook-test https://YOUR-DOMAIN/braintree/webhook'`
   It should print `200 ok`. The test uses a made-up subscription id, so no order is touched.
4. In the Braintree sandbox control panel: gear icon > API > Webhooks > Create New Webhook. Destination URL:
   `https://YOUR-DOMAIN/braintree/webhook`. Select at least: Subscription Charged Successfully, Subscription Charged
   Unsuccessfully, Subscription Went Past Due, Subscription Went Active, Subscription Canceled, Subscription Expired.
   Use Check URL next to it; it should pass.
5. Watch `sudo journalctl -u kb-order -f` for `Webhook subscription_charged_successfully ... applied`.

Notes: a signature check protects the endpoint (a request without a valid Braintree signature gets a 400).
If applying a notification fails, the site answers 500 and forgets the event, so Braintree's retry is processed.
The worker's 5-minute sync stays on as a safety net, so a missed webhook is only a delay. The ngrok domain must
be the same one you gave Braintree; if it changes, update the webhook there.

## Useful queries

    -- everything one customer ordered
    SELECT o.public_id, o.plan_code, COALESCE(d.domain_name, v.vm_name) AS item, o.amount_cents, o.status, o.fulfillment_status
    FROM orders o JOIN customers c ON c.id = o.customer_id
    LEFT JOIN domain_orders d ON d.order_id = o.id LEFT JOIN vm_orders v ON v.order_id = o.id
    WHERE c.email = 'you@example.com';

    -- domain margin: what the customer paid vs what the registrar charged
    SELECT domain_name, price_cents, registrar_cost_cents, price_cents - registrar_cost_cents AS margin_cents FROM domain_orders;

    -- orders that need a person
    SELECT public_id, plan_code, fulfillment_error FROM orders WHERE fulfillment_status IN ('failed','needs_review');

## Things you must know

- **Not run on MariaDB.** This workspace has no MariaDB and cannot install packages, so the tests (69 checks)
  run on SQLite using a mechanical copy of `schema.sql`. The SQL is plain and portable, but run `schema.sql`
  and one test order on your MariaDB before relying on it. The `braintree` and `pymysql` libraries were not
  available either: the tests replace Braintree with a fake, so the real Braintree calls are untested.
- **Webhooks need ngrok** (see above). As a fallback the worker asks Braintree for the state of
  active subscriptions every `SYNC_INTERVAL` seconds (300). That sync also picks up renewals, failed charges and
  cancellations if a webhook is missed.
- **Kill Bill data is not migrated.** Old accounts and subscriptions stay in Kill Bill; they are not in this database.
- **Not done:** deleting the VM when a subscription is cancelled, refunds (do them in Braintree; the sync
  records the refund), and customer login. "My orders" lists the orders placed from the same browser;
  anyone with an order ID can open its status page.
- **Real GoDaddy** (`REGISTRAR=godaddy`) spends real money, registers under your GoDaddy account's contact
  details, and was never run against the live API. See the earlier notes on .eu eligibility.
- If Braintree times out while creating a subscription, the order is marked failed but a subscription may
  exist at Braintree. The log line names the order and card token; check Braintree for it.
