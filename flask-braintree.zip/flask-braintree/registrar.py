"""
Domain registrars behind one interface.

  REGISTRAR=fake      (default) the "registry" is the fake_registry table in the local
                      database. Nothing leaves the machine and nothing costs money.
  REGISTRAR=godaddy   the real GoDaddy v3 API (godaddy.py). Needs GODADDY_TOKEN.

Both return the same dicts. LoggedRegistrar writes every call to godaddy_requests,
so the database shows exactly what was asked of the registrar and what it answered.
"""

import hashlib
import os
from datetime import date

import db
from godaddy import GoDaddy, GoDaddyError, GoDaddyPending

FAKE_COSTS_CENTS = {"com": 1199, "net": 1399, "eu": 899}  # what the fake registrar "charges" us


class RegistrarError(Exception):
    def __init__(self, message, transient=False):
        super().__init__(message)
        self.transient = transient


def _plus_year(d: date) -> date:
    try:
        return d.replace(year=d.year + 1)
    except ValueError:  # 29 February
        return d.replace(year=d.year + 1, day=28)


def split(domain: str):
    label, _, tld = domain.rpartition(".")
    return label, tld


class FakeRegistrar:
    mode = "fake"

    def __init__(self, conn, taken=None):
        self.c = conn
        names = os.environ.get("FAKE_TAKEN_NAMES", "google,example,taken,test,amazon") if taken is None else taken
        self.taken = {n.strip().lower() for n in str(names).split(",") if n.strip()}

    def check(self, domain):
        label, _ = split(domain)
        taken = label in self.taken or self.c.one(
            "SELECT 1 AS x FROM fake_registry WHERE domain_name = %s", (domain,)) is not None
        return {"available": not taken}

    def register(self, domain, consent_at, idempotency_key):
        reg_id = "fake-" + hashlib.sha1(idempotency_key.encode()).hexdigest()[:12]
        same = self.c.one("SELECT * FROM fake_registry WHERE registration_id = %s", (reg_id,))
        if same:  # the same request again: same answer, no second purchase
            return {"registration_id": reg_id, "cost_cents": same["cost_cents"],
                    "registered_at": same["registered_at"], "expires_at": same["expires_at"]}
        if not self.check(domain)["available"]:
            raise RegistrarError(f"{domain} is not available")
        _, tld = split(domain)
        cost = FAKE_COSTS_CENTS.get(tld)
        if cost is None:
            raise RegistrarError(f".{tld} is not supported")
        t = db.now()
        expires = _plus_year(date.today()).strftime("%Y-%m-%d")
        self.c.insert(
            "INSERT INTO fake_registry (domain_name, registration_id, cost_cents, registered_at, expires_at) "
            "VALUES (%s,%s,%s,%s,%s)", (domain, reg_id, cost, t, expires))
        self.c.commit()
        return {"registration_id": reg_id, "cost_cents": cost, "registered_at": t, "expires_at": expires}

    def owns(self, domain, idempotency_key):
        """True if this exact order already registered the name (a crashed earlier attempt)."""
        row = self.c.one("SELECT * FROM fake_registry WHERE domain_name = %s", (domain,))
        if row and row["registration_id"] == "fake-" + hashlib.sha1(idempotency_key.encode()).hexdigest()[:12]:
            return {"registration_id": row["registration_id"], "cost_cents": row["cost_cents"],
                    "registered_at": row["registered_at"], "expires_at": row["expires_at"]}
        return None

    def get(self, domain):
        row = self.c.one("SELECT * FROM fake_registry WHERE domain_name = %s", (domain,))
        return {"expires_at": row["expires_at"]} if row else None

    def renew(self, domain):
        row = self.c.one("SELECT * FROM fake_registry WHERE domain_name = %s", (domain,))
        if not row:
            raise RegistrarError(f"{domain} is not in the registry")
        y, m, d = (int(x) for x in str(row["expires_at"])[:10].split("-"))
        expires = _plus_year(date(y, m, d)).strftime("%Y-%m-%d")
        self.c.execute("UPDATE fake_registry SET expires_at=%s WHERE domain_name=%s", (expires, domain))
        self.c.commit()
        return {"expires_at": expires, "cost_cents": row["cost_cents"]}

    def set_auto_renew_off(self, domain):
        self.c.execute("UPDATE fake_registry SET auto_renew=0 WHERE domain_name=%s", (domain,))
        self.c.commit()


class GoDaddyRegistrar:
    mode = "live"

    def __init__(self, token, base_url="https://api.godaddy.com", max_cost_cents=None):
        self.gd = GoDaddy(token, base_url=base_url)
        self.max_cost = max_cost_cents or {"com": 2500, "net": 2500, "eu": 2000}

    @staticmethod
    def _wrap(exc):
        return RegistrarError(str(exc), transient=getattr(exc, "transient", False))

    def check(self, domain):
        try:
            info = self.gd.check_availability(domain)
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc
        if not info["definitive"]:
            raise RegistrarError(f"GoDaddy could not confirm {domain} yet", transient=True)
        return {"available": info["available"]}

    def register(self, domain, consent_at, idempotency_key):
        _, tld = split(domain)
        try:
            quote = self.gd.quote(domain, 1)
            limit = self.max_cost.get(tld)
            if limit is None or quote["currency"] != "USD" or quote["price_cents"] > limit:
                raise RegistrarError(
                    f"GoDaddy price {quote['price_cents']} {quote['currency']} is above the limit for .{tld}")
            agreed = consent_at.replace(" ", "T") + ("Z" if not consent_at.endswith("Z") else "")
            reg_id = self.gd.register(quote, domain, 1, agreed, [a["type"] for a in quote["agreements"]],
                                      idempotency_key=idempotency_key)
            self.gd.wait_for_registration(reg_id, timeout=100)
            record = self.gd.get_domain(domain) or {}
        except GoDaddyPending as exc:
            raise RegistrarError(str(exc), transient=True) from exc
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc
        return {"registration_id": reg_id, "cost_cents": quote["price_cents"],
                "registered_at": db.now(), "expires_at": str(record.get("expires", ""))[:10] or None}

    def owns(self, domain, idempotency_key):
        """The name is on our GoDaddy account. Only our own orders put names there, and
        domain_orders.domain_name is unique, so it belongs to this order."""
        rec = self.get(domain)
        return {"registration_id": None, "cost_cents": None, "registered_at": db.now(),
                "expires_at": rec["expires_at"]} if rec else None

    def get(self, domain):
        try:
            rec = self.gd.get_domain(domain)
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc
        return {"expires_at": str(rec.get("expires", ""))[:10]} if rec else None

    def renew(self, domain):
        try:
            self.gd.renew(domain, 1)
            rec = self.gd.get_domain(domain) or {}
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc
        return {"expires_at": str(rec.get("expires", ""))[:10] or None, "cost_cents": None}

    def set_auto_renew_off(self, domain):
        try:
            self.gd.set_auto_renew(domain, False)
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc


class LoggedRegistrar:
    """Wraps a registrar and records each call in godaddy_requests."""

    def __init__(self, inner, conn, order_id=None):
        self.inner, self.c, self.order_id = inner, conn, order_id
        self.mode = inner.mode

    def _log(self, action, domain, status, cost=None, reg_id=None, detail=None):
        self.c.insert(
            "INSERT INTO godaddy_requests (order_id, action, mode, domain_name, status, cost_cents, "
            "registration_id, detail, created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (self.order_id, action, self.inner.mode, domain, status, cost, reg_id,
             (detail or "")[:500] or None, db.now()))
        self.c.commit()

    def _call(self, action, domain, fn, describe):
        try:
            result = fn()
        except RegistrarError as exc:
            self._log(action, domain, "error", detail=str(exc))
            raise
        self._log(action, domain, "ok", **describe(result))
        return result

    def check(self, domain):
        return self._call("availability", domain, lambda: self.inner.check(domain),
                          lambda r: {"detail": "available" if r["available"] else "taken"})

    def register(self, domain, consent_at, idempotency_key):
        return self._call("register", domain, lambda: self.inner.register(domain, consent_at, idempotency_key),
                          lambda r: {"cost": r["cost_cents"], "reg_id": r["registration_id"]})

    def renew(self, domain):
        return self._call("renew", domain, lambda: self.inner.renew(domain),
                          lambda r: {"cost": r.get("cost_cents"), "detail": f"expires {r.get('expires_at')}"})

    def set_auto_renew_off(self, domain):
        return self._call("auto_renew_off", domain, lambda: self.inner.set_auto_renew_off(domain), lambda r: {})

    def get(self, domain):
        return self.inner.get(domain)

    def owns(self, domain, idempotency_key):
        return self.inner.owns(domain, idempotency_key)


def make_registrar(conn):
    mode = os.environ.get("REGISTRAR", "fake").strip().lower()
    if mode == "fake":
        return FakeRegistrar(conn)
    if mode == "godaddy":
        token = os.environ.get("GODADDY_TOKEN", "").strip()
        if not token:
            raise RuntimeError("REGISTRAR=godaddy needs GODADDY_TOKEN")
        limits = {}
        for item in os.environ.get("DOMAIN_MAX_COST_CENTS", "").split(","):
            if "=" in item:
                k, v = item.split("=", 1)
                limits[k.strip()] = int(v)
        return GoDaddyRegistrar(token, os.environ.get("GODADDY_BASE_URL", "https://api.godaddy.com"),
                                limits or None)
    raise RuntimeError("REGISTRAR must be 'fake' or 'godaddy'")
