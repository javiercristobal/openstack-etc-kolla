"""
Braintree: customers, cards and subscriptions.

Every method returns plain dicts, so the rest of the code never touches the SDK.
Plans (compute-vm-*, domain-*-annual) are created once in the Braintree control
panel; the price and trial are sent with each subscription, so the order's price
is always the one stored in the plans table.
"""

from decimal import Decimal

import braintree


class BraintreeError(Exception):
    """Braintree could not be reached, or rejected the request unexpectedly."""


class Declined(BraintreeError):
    """Braintree refused the card or the first charge. Safe to show to the customer."""


def _cents(amount) -> int:
    return int((Decimal(str(amount)) * 100).to_integral_value())


def tx_to_dict(tx) -> dict:
    return {
        "id": tx.id,
        "status": str(tx.status),
        "kind": "refund" if str(tx.type) == "credit" else "sale",
        "amount_cents": _cents(tx.amount),
        "currency": tx.currency_iso_code or "USD",
        "processor_response": getattr(tx, "processor_response_text", None),
        "created_at": tx.created_at.strftime("%Y-%m-%d %H:%M:%S") if tx.created_at else None,
    }


def sub_to_dict(sub) -> dict:
    nbd = getattr(sub, "next_billing_date", None)
    return {
        "id": sub.id,
        "status": str(sub.status),
        "next_billing_date": nbd.strftime("%Y-%m-%d") if nbd else None,
        "transactions": [tx_to_dict(t) for t in (sub.transactions or [])],
    }


class Braintree:
    def __init__(self, environment, merchant_id, public_key, private_key):
        env = {
            "sandbox": braintree.Environment.Sandbox,
            "production": braintree.Environment.Production,
        }.get(environment.lower())
        if env is None:
            raise RuntimeError("BT_ENVIRONMENT must be 'sandbox' or 'production'")
        self.gateway = braintree.BraintreeGateway(
            braintree.Configuration(
                environment=env, merchant_id=merchant_id,
                public_key=public_key, private_key=private_key,
            )
        )

    def client_token(self) -> str:
        try:
            return self.gateway.client_token.generate()
        except Exception as exc:
            raise BraintreeError(f"Braintree client token failed: {exc}") from exc

    def ensure_customer(self, customer_id, name, email):
        """Creates the customer if Braintree does not know it yet. Safe to repeat."""
        try:
            self.gateway.customer.find(customer_id)
            return
        except braintree.exceptions.NotFoundError:
            pass
        except Exception as exc:
            raise BraintreeError(f"Braintree lookup failed: {exc}") from exc
        first, _, last = name.strip().partition(" ")
        try:
            result = self.gateway.customer.create(
                {"id": customer_id, "first_name": first, "last_name": last, "email": email}
            )
        except Exception as exc:
            raise BraintreeError(f"Braintree customer create failed: {exc}") from exc
        if not result.is_success:
            raise BraintreeError(f"Braintree rejected the customer: {result.message}")

    def add_card(self, customer_id, nonce) -> dict:
        """Stores the card in the vault, verifying it first. Returns token and display details."""
        try:
            result = self.gateway.payment_method.create({
                "customer_id": customer_id,
                "payment_method_nonce": nonce,
                "options": {"verify_card": True},
            })
        except Exception as exc:
            raise BraintreeError(f"Braintree card save failed: {exc}") from exc
        if not result.is_success:
            raise Declined(result.message or "The card was not accepted.")
        pm = result.payment_method
        return {
            "token": pm.token,
            "card_type": getattr(pm, "card_type", None) or type(pm).__name__,
            "last4": getattr(pm, "last_4", None),
            "expiration": getattr(pm, "expiration_date", None),
        }

    def subscribe(self, token, plan_id, price_cents, trial_days) -> dict:
        """Creates the subscription. With no trial the first charge happens now."""
        data = {
            "payment_method_token": token,
            "plan_id": plan_id,
            "price": f"{Decimal(price_cents) / 100:.2f}",
            "trial_period": bool(trial_days),
        }
        if trial_days:
            data["trial_duration"] = trial_days
            data["trial_duration_unit"] = braintree.Subscription.TrialDurationUnit.Day
        try:
            result = self.gateway.subscription.create(data)
        except Exception as exc:
            raise BraintreeError(f"Braintree subscription failed: {exc}") from exc
        if not result.is_success:
            raise Declined(result.message or "The payment was declined.")
        return sub_to_dict(result.subscription)

    def find_subscription(self, subscription_id) -> dict:
        try:
            return sub_to_dict(self.gateway.subscription.find(subscription_id))
        except Exception as exc:
            raise BraintreeError(f"Braintree subscription lookup failed: {exc}") from exc

    def cancel_subscription(self, subscription_id):
        try:
            self.gateway.subscription.cancel(subscription_id)
        except Exception as exc:
            raise BraintreeError(f"Braintree cancel failed: {exc}") from exc

    def parse_webhook(self, signature, payload):
        """Verifies the signature. Returns (kind, subscription dict or None)."""
        try:
            note = self.gateway.webhook_notification.parse(signature, payload)
        except Exception as exc:
            raise BraintreeError(f"Webhook rejected: {exc}") from exc
        sub = getattr(note, "subscription", None)
        return str(note.kind), (sub_to_dict(sub) if sub else None)
