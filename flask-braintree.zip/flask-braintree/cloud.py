"""OpenStack: boot a VM and attach a floating IP. Each step is safe to repeat."""

import logging
import os

try:
    import openstack
except ImportError:  # only needed when a VM is actually created
    openstack = None

log = logging.getLogger("worker.cloud")

OS_IMAGE_NAME = os.environ.get("VM_IMAGE", "ubuntu-24.04")
OS_NETWORK_NAME = os.environ.get("VM_NETWORK", "private")
OS_FLOATING_NETWORK_NAME = os.environ.get("VM_FLOATING_NETWORK", "").strip()
OS_KEY_NAME = os.environ.get("VM_KEY_NAME", "").strip()
OS_SECURITY_GROUP = os.environ.get("VM_SECURITY_GROUP", "").strip()


def create_openstack_vm(vm_name: str, flavor_name: str) -> str:
    """Boots the VM with the given flavor and returns its server id."""
    if openstack is None:
        raise RuntimeError("openstacksdk is not installed (pip install openstacksdk)")

    conn = openstack.connect()  # clouds.yaml or OS_* variables

    # If a previous attempt booted the VM but crashed before recording its id,
    # reuse it instead of creating a duplicate.
    existing = conn.compute.find_server(vm_name)
    if existing:
        log.info("VM %s already exists (id=%s), reusing", vm_name, existing.id)
        return existing.id

    image = conn.compute.find_image(OS_IMAGE_NAME)
    flavor = conn.compute.find_flavor(flavor_name)
    network = conn.network.find_network(OS_NETWORK_NAME)
    missing = [
        f"{kind} '{name}'"
        for kind, name, found in (
            ("image", OS_IMAGE_NAME, image),
            ("flavor", flavor_name, flavor),
            ("network", OS_NETWORK_NAME, network),
        )
        if not found
    ]
    if missing:
        raise RuntimeError("Not found in OpenStack: " + ", ".join(missing))

    extra = {}
    if OS_KEY_NAME:
        extra["key_name"] = OS_KEY_NAME
    if OS_SECURITY_GROUP:
        extra["security_groups"] = [{"name": OS_SECURITY_GROUP}]
    server = conn.compute.create_server(
        name=vm_name,
        image_id=image.id,
        flavor_id=flavor.id,
        networks=[{"uuid": network.id}],
        **extra,
    )
    server = conn.compute.wait_for_server(server, wait=300)
    log.info("OpenStack VM created: id=%s name=%s flavor=%s status=%s",
             server.id, server.name, flavor_name, server.status)
    return server.id


def _floating_network(conn):
    if OS_FLOATING_NETWORK_NAME:
        net = conn.network.find_network(OS_FLOATING_NETWORK_NAME)
        if not net:
            raise RuntimeError(f"Floating IP network '{OS_FLOATING_NETWORK_NAME}' not found")
        return net
    external = list(conn.network.networks(**{"router:external": True}))
    if len(external) != 1:
        names = [n.name for n in external]
        raise RuntimeError(
            "Set VM_FLOATING_NETWORK: expected exactly one external network, found "
            f"{len(external)} {names}"
        )
    return external[0]


def ensure_floating_ip(server_id: str, vm_name: str) -> str:
    """Attaches a floating IP to the server and returns its address.

    Safe to repeat: if the server already has one, that address is returned.
    """
    if openstack is None:
        raise RuntimeError("openstacksdk is not installed (pip install openstacksdk)")
    conn = openstack.connect()

    ports = list(conn.network.ports(device_id=server_id))
    if not ports:
        raise RuntimeError(f"Server {server_id} has no network port yet")
    port = ports[0]

    for fip in conn.network.ips(port_id=port.id):
        log.info("Server %s already has floating IP %s", server_id, fip.floating_ip_address)
        return fip.floating_ip_address

    fixed = next(
        (f["ip_address"] for f in port.fixed_ips if ":" not in f.get("ip_address", "")), None
    )
    ext = _floating_network(conn)
    fip = conn.network.create_ip(
        floating_network_id=ext.id,
        port_id=port.id,
        fixed_ip_address=fixed,
        description=f"kill bill order {vm_name}",
    )
    log.info("Floating IP %s attached to %s (%s)", fip.floating_ip_address, vm_name, server_id)
    return fip.floating_ip_address
