-- Run once as the MariaDB admin:  sudo mariadb < deploy/mariadb-setup.sql
-- Then change both passwords.
CREATE DATABASE IF NOT EXISTS flask_orders CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- The site, on the same machine as MariaDB
CREATE USER IF NOT EXISTS 'orders'@'localhost' IDENTIFIED BY 'change-me';
GRANT ALL PRIVILEGES ON flask_orders.* TO 'orders'@'localhost';

-- The worker, on the OpenStack controller (use its address on the network the Flask VM can reach)
CREATE USER IF NOT EXISTS 'orders'@'192.168.42.40' IDENTIFIED BY 'change-me';
GRANT SELECT, INSERT, UPDATE, DELETE ON flask_orders.* TO 'orders'@'192.168.42.40';
FLUSH PRIVILEGES;
