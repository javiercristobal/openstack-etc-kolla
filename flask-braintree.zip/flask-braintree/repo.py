"""All SQL for the order site and the worker."""

import uuid

from db import IntegrityError, now
from plans import PLANS

SUCCESS_TX = ("authorized", "submitted_for_settlement", "settling", "settled", "settlement_confirmed")


# ---- plans ----
def seed_plans(c):
    """Inserts missing plans and refreshes the existing ones from plans.py."""
    for p in PLANS:
        row = {"flavor": None, "tld": None, **p}
        if c.one("SELECT code FROM plans WHERE code = %s", (p["code"],)):
            c.execute(
                "UPDATE plans SET title=%s, price_cents=%s, billing_period=%s, trial_days=%s, "
                "braintree_plan_id=%s, flavor=%s, tld=%s WHERE code=%s",
                (row["title"], row["price_cents"], row["billing_period"], row["trial_days"],
                 row["braintree_plan_id"], row["flavor"], row["tld"], row["code"]),
            )
        else:
            c.execute(
                "INSERT INTO plans (code, product_type, title, price_cents, currency, billing_period, "
                "trial_days, braintree_plan_id, flavor, tld, active) VALUES (%s,%s,%s,%s,'USD',%s,%s,%s,%s,%s,1)",
                (row["code"], row["product_type"], row["title"], row["price_cents"], row["billing_period"],
                 row["trial_days"], row["braintree_plan_id"], row["flavor"], row["tld"]),
            )
    c.commit()


def get_plan(c, code):
    return c.one("SELECT * FROM plans WHERE code = %s AND active = 1", (code,))


def list_plans(c, product_type):
    return c.all("SELECT * FROM plans WHERE product_type = %s AND active = 1 ORDER BY price_cents", (product_type,))


def domain_plan_for_tld(c, tld):
    return c.one("SELECT * FROM plans WHERE product_type='domain' AND tld = %s AND active = 1", (tld,))


# ---- customers and cards ----
def get_or_create_customer(c, name, email):
    """One customer per email; the same customer can place many orders."""
    row = c.one("SELECT * FROM customers WHERE email = %s", (email,))
    if row:
        return row, False
    try:
        cid = c.insert(
            "INSERT INTO customers (email, name, braintree_customer_id, created_at) VALUES (%s,%s,%s,%s)",
            (email, name, str(uuid.uuid4()), now()),
        )
        c.commit()
    except IntegrityError:  # two requests for the same new email
        c.rollback()
        return c.one("SELECT * FROM customers WHERE email = %s", (email,)), False
    return c.one("SELECT * FROM customers WHERE id = %s", (cid,)), True


def save_payment_method(c, customer_id, card):
    row = c.one("SELECT * FROM payment_methods WHERE braintree_token = %s", (card["token"],))
    if row:
        return row["id"]
    pid = c.insert(
        "INSERT INTO payment_methods (customer_id, braintree_token, card_type, last4, expiration, created_at) "
        "VALUES (%s,%s,%s,%s,%s,%s)",
        (customer_id, card["token"], card["card_type"], card["last4"], card["expiration"], now()),
    )
    c.commit()
    return pid


# ---- orders ----
def create_order(c, customer_id, plan, payment_method_id, vm_name=None, domain=None, consent_at=None):
    """Inserts the order and its VM/domain row in one transaction, status 'pending'.

    Raises IntegrityError if the domain is already ordered.
    """
    public_id = str(uuid.uuid4())
    t = now()
    if vm_name:  # the short id keeps names unique across orders, and in OpenStack
        vm_name = f"{vm_name}-{public_id[:8]}"
    with c.tx():
        order_id = c.insert(
            "INSERT INTO orders (public_id, customer_id, plan_code, product_type, status, fulfillment_status, "
            "amount_cents, currency, billing_period, trial_days, payment_method_id, created_at, updated_at) "
            "VALUES (%s,%s,%s,%s,'pending','pending',%s,%s,%s,%s,%s,%s,%s)",
            (public_id, customer_id, plan["code"], plan["product_type"], plan["price_cents"], plan["currency"],
             plan["billing_period"], plan["trial_days"], payment_method_id, t, t),
        )
        if plan["product_type"] == "vm":
            c.insert("INSERT INTO vm_orders (order_id, vm_name, flavor) VALUES (%s,%s,%s)",
                     (order_id, vm_name, plan["flavor"]))
        else:
            c.insert(
                "INSERT INTO domain_orders (order_id, domain_name, tld, price_cents, currency, consent_at) "
                "VALUES (%s,%s,%s,%s,%s,%s)",
                (order_id, domain, plan["tld"], plan["price_cents"], plan["currency"], consent_at),
            )
    return order_id, public_id


def fail_order(c, order_id, reason):
    """Marks the order failed and frees its VM name or domain for someone else."""
    with c.tx():
        c.execute("UPDATE orders SET status='failed', failure_reason=%s, updated_at=%s WHERE id=%s",
                  (reason[:255], now(), order_id))
        c.execute("DELETE FROM vm_orders WHERE order_id = %s", (order_id,))
        c.execute("DELETE FROM domain_orders WHERE order_id = %s", (order_id,))


def attach_subscription(c, order_id, sub):
    c.execute("UPDATE orders SET braintree_subscription_id=%s, updated_at=%s WHERE id=%s",
              (sub["id"], now(), order_id))
    c.commit()


ORDER_SELECT = (
    "SELECT o.*, c.email, c.name AS customer_name, p.title AS plan_title, "
    "v.vm_name, v.flavor, v.openstack_server_id, v.floating_ip, "
    "d.domain_name, d.price_cents AS domain_price_cents, d.registrar, d.registrar_registration_id, "
    "d.registered_at, d.expires_at, d.years_paid, d.auto_renew, d.registrar_cost_cents "
    "FROM orders o JOIN customers c ON c.id = o.customer_id JOIN plans p ON p.code = o.plan_code "
    "LEFT JOIN vm_orders v ON v.order_id = o.id LEFT JOIN domain_orders d ON d.order_id = o.id "
)


def get_order_by_public_id(c, public_id):
    return c.one(ORDER_SELECT + "WHERE o.public_id = %s", (public_id,))


def get_order(c, order_id):
    return c.one(ORDER_SELECT + "WHERE o.id = %s", (order_id,))


def orders_for_customer(c, customer_id):
    return c.all(ORDER_SELECT + "WHERE o.customer_id = %s ORDER BY o.id DESC", (customer_id,))


def orders_for_email(c, email):
    return c.all(ORDER_SELECT + "WHERE c.email = %s ORDER BY o.id DESC", (email,))


# ---- transactions ----
def record_transactions(c, order, txs):
    """Idempotent: a Braintree transaction is stored once. Returns how many were new."""
    new = 0
    for tx in txs:
        if c.one("SELECT id FROM transactions WHERE braintree_transaction_id = %s", (tx["id"],)):
            c.execute("UPDATE transactions SET status=%s WHERE braintree_transaction_id=%s",
                      (tx["status"], tx["id"]))
            continue
        c.insert(
            "INSERT INTO transactions (order_id, customer_id, braintree_transaction_id, kind, amount_cents, "
            "currency, status, processor_response, occurred_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (order["id"], order["customer_id"], tx["id"], tx["kind"], tx["amount_cents"], tx["currency"],
             tx["status"], (tx.get("processor_response") or "")[:120] or None, tx["created_at"] or now()),
        )
        new += 1
    c.commit()
    return new


def successful_sales(c, order_id):
    marks = ",".join(["%s"] * len(SUCCESS_TX))
    row = c.one(
        f"SELECT COUNT(*) AS n FROM transactions WHERE order_id=%s AND kind='sale' AND status IN ({marks})",
        (order_id, *SUCCESS_TX),
    )
    return int(row["n"])


def transactions_for_order(c, order_id):
    return c.all("SELECT * FROM transactions WHERE order_id = %s ORDER BY id", (order_id,))
