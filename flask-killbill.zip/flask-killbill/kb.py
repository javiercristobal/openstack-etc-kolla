"""Thin Kill Bill REST client used by the order site."""

import json

import requests


class KillBillError(Exception):
    def __init__(self, message, status=None, body=None):
        super().__init__(message)
        self.status = status
        self.body = body


def parse_client_token(text: str) -> str:
    """
    The plugin docs promise a "client token payload" but not its shape, so
    accept a bare token, a JSON string, or a JSON object with a known key.
    """
    text = (text or "").strip()
    if not text:
        raise KillBillError("Empty client token response")
    try:
        data = json.loads(text)
    except ValueError:
        return text  # bare token (Braintree tokens are base64, not JSON)
    if isinstance(data, str) and data:
        return data
    if isinstance(data, dict):
        for key in ("clientToken", "client_token", "token", "value"):
            value = data.get(key)
            if isinstance(value, str) and value:
                return value
        raise KillBillError(f"Unrecognised client token response (keys: {sorted(data)})")
    raise KillBillError("Unrecognised client token response")


class KillBill:
    def __init__(self, base_url, user, password, api_key, api_secret,
                 created_by="flask-killbill", timeout=20):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.auth = (user, password)
        self.session.headers.update({
            "X-Killbill-ApiKey": api_key,
            "X-Killbill-ApiSecret": api_secret,
            "X-Killbill-CreatedBy": created_by,
            "Accept": "application/json",
        })

    # ---- plumbing ----
    def _request(self, method, path, **kwargs):
        url = f"{self.base_url}{path}"
        try:
            resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        except requests.RequestException as exc:
            raise KillBillError(f"Cannot reach Kill Bill at {self.base_url}: {exc}") from exc
        if resp.status_code >= 400:
            raise KillBillError(
                f"{method} {path} failed with HTTP {resp.status_code}",
                status=resp.status_code,
                body=(resp.text or "")[:500],
            )
        return resp

    @staticmethod
    def _id_from_location(resp, what):
        location = resp.headers.get("Location")
        if not location:
            raise KillBillError(f"Kill Bill did not return a Location header for the new {what}")
        return location.rstrip("/").split("/")[-1]

    # ---- Braintree plugin ----
    def client_token(self) -> str:
        resp = self._request("GET", "/plugins/killbill-braintree/clientToken")
        return parse_client_token(resp.text)

    # ---- writes ----
    def create_account(self, name, email, external_key):
        resp = self._request("POST", "/1.0/kb/accounts", json={
            "name": name,
            "externalKey": external_key,
            "email": email,
            "currency": "USD",
        })
        return self._id_from_location(resp, "account")

    def add_card(self, account_id, nonce, bt_customer_id, payment_method_type=None):
        properties = [
            {"key": "bt_nonce", "value": nonce},
            {"key": "bt_customer_id", "value": bt_customer_id},
        ]
        if payment_method_type:
            properties.append({"key": "payment_method_type", "value": payment_method_type})
        resp = self._request(
            "POST",
            f"/1.0/kb/accounts/{account_id}/paymentMethods",
            params={"isDefault": "true"},
            json={"pluginName": "killbill-braintree", "pluginInfo": {"properties": properties}},
        )
        return self._id_from_location(resp, "payment method")

    def create_subscription(self, account_id, plan_name):
        # Kill Bill rejects priceList when planName is given (the plan already
        # belongs to a price list), so send only these two fields.
        resp = self._request("POST", "/1.0/kb/subscriptions", json={
            "accountId": account_id,
            "planName": plan_name,
        })
        return self._id_from_location(resp, "subscription")

    def tag_vm_name(self, subscription_id, vm_name):
        self._request(
            "POST",
            f"/1.0/kb/subscriptions/{subscription_id}/customFields",
            json=[{"objectType": "SUBSCRIPTION", "name": "vm_name", "value": vm_name}],
        )

    # ---- reads ----
    def get_subscription(self, subscription_id):
        return self._request("GET", f"/1.0/kb/subscriptions/{subscription_id}").json()

    def get_custom_fields(self, subscription_id):
        resp = self._request("GET", f"/1.0/kb/subscriptions/{subscription_id}/customFields")
        fields = resp.json() if resp.content else []
        return {f["name"]: f.get("value") for f in fields if "name" in f}

    def nodes_info(self):
        return self._request("GET", "/1.0/kb/nodesInfo").json()
