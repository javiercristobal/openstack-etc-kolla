"""
Braintree customer creation.

The Kill Bill Braintree plugin does not create the Braintree customer itself:
adding a card needs a bt_customer_id that already exists in Braintree. So the
order site creates the customer first, using the Kill Bill account id as the
Braintree customer id (letters, digits, dashes: Braintree accepts a UUID).
"""

import braintree


class BraintreeError(Exception):
    pass


class BraintreeCustomers:
    def __init__(self, environment, merchant_id, public_key, private_key):
        env = {
            "sandbox": braintree.Environment.Sandbox,
            "production": braintree.Environment.Production,
        }.get(environment.lower())
        if env is None:
            raise RuntimeError("BT_ENVIRONMENT must be 'sandbox' or 'production'")
        self.gateway = braintree.BraintreeGateway(
            braintree.Configuration(
                environment=env,
                merchant_id=merchant_id,
                public_key=public_key,
                private_key=private_key,
            )
        )

    def ensure_customer(self, customer_id, name, email):
        """Create the customer if it does not exist yet. Safe to call twice."""
        try:
            self.gateway.customer.find(customer_id)
            return
        except braintree.exceptions.NotFoundError:
            pass
        except Exception as exc:  # network, auth, etc.
            raise BraintreeError(f"Braintree lookup failed: {exc}") from exc

        first, _, last = name.strip().partition(" ")
        try:
            result = self.gateway.customer.create({
                "id": customer_id,
                "first_name": first,
                "last_name": last,
                "email": email,
            })
        except Exception as exc:
            raise BraintreeError(f"Braintree customer create failed: {exc}") from exc
        if not result.is_success:
            raise BraintreeError(f"Braintree rejected the customer: {result.message}")
