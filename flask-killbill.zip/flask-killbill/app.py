"""
VM order site.

Collects a VM order and a card (via Braintree Drop-in, so the card number goes
straight to Braintree and never touches this server), then hands the order to
Kill Bill:

    account -> card (nonce) -> subscription -> vm_name tag

Kill Bill then fires SUBSCRIPTION_CREATION and webhook_listener.py on the
OpenStack controller creates the VM. This site only reads progress back.

Required environment: SECRET_KEY, KB_ADMIN_PASSWORD, KB_API_KEY, KB_API_SECRET
(see deploy/kb-order.env.example).
"""

import hmac
import logging
import os
import re
import secrets
import uuid

import click
from flask import Flask, abort, redirect, render_template, request, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

from kb import KillBill, KillBillError

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("flask-killbill")

_REQUIRED = ("SECRET_KEY", "KB_ADMIN_PASSWORD", "KB_API_KEY", "KB_API_SECRET")
_missing = [name for name in _REQUIRED if not os.environ.get(name)]
if _missing:
    raise RuntimeError("Missing required environment variable(s): " + ", ".join(_missing))

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)  # behind nginx
app.config.update(
    SECRET_KEY=os.environ["SECRET_KEY"],
    # Set SESSION_COOKIE_SECURE=0 only while testing over plain http.
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "1") == "1",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SITE_NAME=os.environ.get("SITE_NAME", "cloud.lab"),
    SHOW_TEST_CARD_HINT=os.environ.get("SHOW_TEST_CARD_HINT", "1") == "1",
)

kb = KillBill(
    base_url=os.environ.get("KB_BASE_URL", "http://127.0.0.1:8080"),
    user=os.environ.get("KB_ADMIN_USER", "admin"),
    password=os.environ["KB_ADMIN_PASSWORD"],
    api_key=os.environ["KB_API_KEY"],
    api_secret=os.environ["KB_API_SECRET"],
)

# Only set this if the plugin rejects orders without it (CARD, PAYPAL or ACH).
BT_PAYMENT_METHOD_TYPE = os.environ.get("BT_PAYMENT_METHOD_TYPE", "").strip() or None

# Plans offered on the form, keyed by catalog plan name. Every plan here gets
# the same OpenStack image and flavor from the listener, so only list plans
# that should produce the same VM.
PLANS = {
    "compute-vm-basic": {"title": "Virtual machine", "price": "$10 per month"},
}

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
VM_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,28}[a-z0-9]$")  # 3 to 30 characters


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def csrf_token() -> str:
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


def check_csrf() -> None:
    sent = request.form.get("csrf_token", "")
    expected = session.get("csrf", "")
    if not expected or not hmac.compare_digest(sent, expected):
        log.warning("CSRF check failed (if this is plain http, set SESSION_COOKIE_SECURE=0)")
        abort(400)


def clean_form() -> dict:
    return {
        "name": request.form.get("name", "").strip(),
        "email": request.form.get("email", "").strip().lower(),
        "vm_name": request.form.get("vm_name", "").strip().lower(),
        "plan": request.form.get("plan", "").strip(),
        "nonce": request.form.get("payment_method_nonce", "").strip(),
    }


def validate(form: dict) -> list:
    errors = []
    if not 2 <= len(form["name"]) <= 100:
        errors.append("Enter your full name.")
    if len(form["email"]) > 254 or not EMAIL_RE.match(form["email"]):
        errors.append("Enter a valid email address.")
    if not VM_NAME_RE.match(form["vm_name"]):
        errors.append("Name the VM with 3 to 30 lowercase letters, numbers or hyphens, "
                      "starting and ending with a letter or number.")
    if form["plan"] not in PLANS:
        errors.append("Choose a plan.")
    if not form["nonce"]:
        errors.append("Enter your card details.")
    return errors


def render_order(form=None, errors=None, status=200):
    try:
        token = kb.client_token()
    except KillBillError as exc:
        log.error("Could not get a Braintree client token: %s %s", exc, exc.body)
        return render_template(
            "error.html",
            title="Ordering is unavailable",
            message="The payment service isn't responding. Try again in a few minutes.",
        ), 503
    return render_template(
        "order.html",
        client_token=token,
        plans=PLANS,
        form=form or {},
        errors=errors or [],
    ), status


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if not request.path.startswith("/static/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


@app.errorhandler(400)
def bad_request(_exc):
    return render_template(
        "error.html",
        title="This form has expired",
        message="Reload the page and submit the order again.",
    ), 400


@app.errorhandler(404)
def not_found(_exc):
    return render_template(
        "error.html",
        title="Page not found",
        message="Check the address, or start a new order.",
    ), 404


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
@app.get("/")
def order_form():
    return render_order()


@app.post("/order")
def order_submit():
    check_csrf()
    form = clean_form()
    errors = validate(form)
    if errors:
        return render_order(form, errors, 400)

    # If an earlier attempt got as far as creating the account (for example the
    # card was declined), reuse it instead of leaving orphans behind.
    pending = session.get("pending") or {}
    if pending.get("email") != form["email"]:
        pending = {}

    try:
        account_id = pending.get("account_id")
        if not account_id:
            account_id = kb.create_account(
                form["name"], form["email"], f"order-{uuid.uuid4().hex[:12]}"
            )
            pending = {"account_id": account_id, "email": form["email"], "card": False}
            session["pending"] = pending
    except KillBillError as exc:
        log.error("Account creation failed: %s %s", exc, exc.body)
        return render_order(form, ["We couldn't create your account. Try again in a minute."], 502)

    if not pending.get("card"):
        try:
            kb.add_card(account_id, form["nonce"], BT_PAYMENT_METHOD_TYPE)
        except KillBillError as exc:
            log.error("Card not saved for account %s: %s %s", account_id, exc, exc.body)
            return render_order(
                form, ["We couldn't save that card. Check the details or try another card."], 402
            )
        pending["card"] = True
        session["pending"] = pending

    try:
        subscription_id = kb.create_subscription(account_id, form["plan"])
    except KillBillError as exc:
        log.error("Subscription failed for account %s: %s %s", account_id, exc, exc.body)
        return render_order(
            form, ["Your card is saved, but we couldn't place the order. Try again in a minute."], 502
        )

    # The listener boots the VM under this exact name. The subscription id keeps
    # it unique, because the listener reuses an existing server with the same name.
    vm_name = f"{form['vm_name']}-{subscription_id[:8]}"
    try:
        kb.tag_vm_name(subscription_id, vm_name)
    except KillBillError as exc:
        # Not fatal: the listener falls back to vm-<subscription id>.
        log.error("Could not tag vm_name on %s: %s %s", subscription_id, exc, exc.body)

    session.pop("pending", None)
    session.pop("csrf", None)
    log.info("Order placed: account=%s subscription=%s vm=%s", account_id, subscription_id, vm_name)
    return redirect(url_for("order_status", subscription_id=subscription_id), 303)


@app.get("/order/<subscription_id>")
def order_status(subscription_id):
    try:
        uuid.UUID(subscription_id)
    except ValueError:
        abort(404)
    try:
        sub = kb.get_subscription(subscription_id)
        fields = kb.get_custom_fields(subscription_id)
    except KillBillError as exc:
        if exc.status == 404:
            abort(404)
        log.error("Status lookup failed for %s: %s %s", subscription_id, exc, exc.body)
        return render_template(
            "error.html",
            title="Status is unavailable",
            message="We can't read the order status right now. Reload in a minute.",
        ), 503

    server_id = fields.get("openstack_server_id")
    if sub.get("state") not in (None, "ACTIVE"):
        phase = "inactive"
    elif server_id:
        phase = "ready"
    else:
        phase = "pending"

    plan = PLANS.get(sub.get("planName"), {"title": sub.get("planName") or "Virtual machine", "price": ""})
    return render_template(
        "status.html",
        phase=phase,
        subscription_id=subscription_id,
        sub_state=sub.get("state"),
        plan=plan,
        vm_name=fields.get("vm_name"),
        server_id=server_id,
    )


@app.get("/healthz")
def healthz():
    return "ok"


@app.cli.command("check")
def check_command():
    """Confirm Kill Bill is reachable and the Braintree plugin issues client tokens."""
    try:
        nodes = kb.nodes_info()
    except KillBillError as exc:
        raise click.ClickException(f"Kill Bill check failed: {exc} {exc.body or ''}")
    states = [
        p.get("state")
        for node in nodes
        for p in node.get("pluginsInfo", [])
        if p.get("pluginKey") == "braintree"
    ]
    click.echo(f"Kill Bill reachable. braintree plugin state: {states or 'not installed'}")
    try:
        token = kb.client_token()
    except KillBillError as exc:
        raise click.ClickException(f"Client token request failed: {exc} {exc.body or ''}")
    click.echo(f"Client token OK ({len(token)} characters).")
