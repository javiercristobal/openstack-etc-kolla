# flask-order: VM and domain orders on Kill Bill

Order site (Flask) -> Kill Bill -> webhook on the OpenStack controller. This is your
`flask-killbill.zip` site, plus domain names (.com, .net, .eu).

| Product | Plans | Result |
|---|---|---|
| Virtual machine | compute-vm-basic / medium / large (30 days free, then monthly) | VM + floating IP in OpenStack |
| Domain | domain-com-annual, domain-net-annual, domain-eu-annual (yearly, no trial) | Domain registered after the payment succeeds. **Fake by default.** |

I could not deploy this for you: I have no access to your servers. The install scripts do the
copying and restarting; you run them.

## What is real and what is fake

| Step | Default |
|---|---|
| Does the name already exist? (on the site, and again before registering) | **Real.** Public registry data (RDAP) for .com/.net/.eu, or GoDaddy's availability API if you give it a token. |
| Is the name already ordered by someone else on this site? | **Real.** Looked up in Kill Bill (active subscriptions with that `domain_name`). |
| Taking the payment | Real, through Kill Bill and Braintree (sandbox in your lab). |
| Registering the domain | **Fake.** `REGISTRAR=fake`: a line is written to `/var/lib/kb-webhook/fake_registry.json` on the controller. Nothing is bought and nothing leaves the machine. |

A name that exists on the real internet is refused even in fake mode, so what you see on the site matches reality.
Because the fake registry is local, the "domain" does not really exist: it won't resolve and `whois` won't show it.

## What is in the zip

- `site/` goes to `/opt/flask-killbill` on the Flask VM
- `webhook/` goes to `/opt/kb-webhook` on the OpenStack controller
- `catalog/openstack-billing-plans-v3.xml`: catalog version 3, your VM plans plus the three domain plans
- `scripts/`: install-site.sh, install-webhook.sh, upload-catalog.sh (they keep your env files and venvs, and back up the old code)
- `tests/`: `python3 tests/test_site.py`, `test_listener.py`, `test_domaincheck.py`

## How a domain order works

1. `/domain`: the customer types a name and picks .com, .net or .eu. The site checks that it does not exist (registry or GoDaddy) and is not held by another order.
2. The customer enters name, email and card, and accepts the registration agreement.
3. The site checks again, creates the Kill Bill account, saves the card, creates the subscription (`domain-<ext>-annual`) and stores `domain_name` and the consent time as custom fields.
4. Kill Bill charges the yearly price and sends `INVOICE_PAYMENT_SUCCESS` to the webhook.
5. The webhook finds the account's fully paid invoice for that subscription, checks the name once more, and registers it with the registrar (fake file, or GoDaddy). It writes `domain_status=registered`, `domain_expires` and `domain_registration_id` on the subscription.
6. Each later paid yearly invoice renews the domain for one year (skipped if it is already renewed).

If the name turns out to exist when the webhook checks (someone else registered it in between), the order is marked `needs-review`, nothing is registered, and the customer has to be refunded in Kaui.

Custom fields on the subscription (visible in Kaui): `domain_name`, `domain_consent`, `domain_status`
(`registering`, `registered`, `failed`, `needs-review`), `domain_registration_id`, `domain_expires`, `domain_paid_count`.

## Deploy, in this order

### 1. Catalog (from any machine that reaches Kill Bill)

    export KB_URL=http://killbill.cloud.lab:8080
    export KB_ADMIN_PASSWORD=... KB_API_KEY=... KB_API_SECRET=...
    bash scripts/upload-catalog.sh

The effective date is 2026-11-09T12:00:00Z. If Kill Bill says the date already exists, change
`<effectiveDate>` to a later unused one. Prices ($18 .com, $20 .net, $14 .eu) are placeholders; the site shows the
same prices from `DOMAIN_TLDS` in `site/app.py`, so keep both in step.

### 2. Controller (webhook)

Add to `/etc/kb-webhook.env` (see `webhook/kb-webhook.env.example`):

    REGISTRAR=fake
    REGISTRY_FILE=/var/lib/kb-webhook/fake_registry.json
    DOMAIN_CHECK=auto

Then `sudo bash scripts/install-webhook.sh`. It creates `/var/lib/kb-webhook`, gives it to the service user,
restarts `kb-webhook`, and prints the registrar mode. Check `sudo journalctl -u kb-webhook -n 30 --no-pager`.
The controller needs outbound HTTPS to `data.iana.org` and the registries (rdap.verisign.com, and the .eu registry).

### 3. Flask VM (site)

Add to `/etc/kb-order.env`: `DOMAIN_CHECK=auto` (nothing else is needed). Then `sudo bash scripts/install-site.sh`.
Open `https://flask-killbill.cloud.lab/domain`.

### 4. Check it

From the Flask VM, without placing an order:

    cd /opt/flask-killbill && sudo -u www-data bash -c 'set -a; . /etc/kb-order.env; set +a; venv/bin/python check_domain.py google.com example.net zzqx-no-such-name-91.eu'

`google.com` should say EXISTS and the made-up name AVAILABLE. Then order a domain with the sandbox card and look
at `/var/lib/kb-webhook/fake_registry.json` on the controller.

## Going live with GoDaddy later

On the controller set `REGISTRAR=godaddy`, `GODADDY_TOKEN` (Personal Access Token with `domains.domain:read`,
`:create`, `:update`) and `DOMAIN_MAX_COST_CENTS=com=2500,net=2500,eu=2000`, then restart `kb-webhook`.
To make the site's existence check use GoDaddy too, add a read-only token as `GODADDY_TOKEN` in `/etc/kb-order.env`
(`DOMAIN_CHECK=auto` then uses it). A GoDaddy check also knows reserved and premium names that RDAP reports as "not found".

## Things you must know

- **Existence is not the same as "can be registered".** RDAP says whether a name is registered. A reserved, blocked or premium name is "not found" there but cannot be bought; GoDaddy's check catches those, or the registration fails and the order becomes `needs-review`. If a registry cannot be reached, the site says it cannot check; it never assumes "available".
- **Not tested live.** This workspace cannot reach the registries, GoDaddy or Kill Bill, so the RDAP and GoDaddy calls follow their published documentation and are tested only with fakes (73 checks across 3 test files). Run the `check_domain.py` command above first.
- **Two buyers at the same moment.** The site refuses a name held by an active order, but two orders placed within seconds can both pass. The webhook then registers one, and marks the other `needs-review`.
- **Real GoDaddy spends real money**, registers under your GoDaddy account's contact details (not the customer's), and needs a .eu-eligible profile for .eu. The Braintree side is sandbox in this lab, so a "paid" test order would cost you real money at GoDaddy.
- **Refunds and cancellation.** Failed or `needs-review` orders are not refunded automatically: refund in Kaui. Cancelling a subscription stops future renewals only.
- Keep `--workers 1` for the listener (its lock is per process).
