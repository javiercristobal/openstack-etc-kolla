import json, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
REGFILE = os.path.join(tempfile.mkdtemp(), "reg", "fake_registry.json")
os.environ.update(KB_ADMIN_PASSWORD="x", KB_API_KEY="k", KB_API_SECRET="s", REGISTRAR="fake", REGISTRY_FILE=REGFILE,
                  DOMAIN_CHECK="rdap")
sys.path.insert(0, os.path.join(HERE, "..", "webhook"))
import webhook_listener as wl
import registrar as rg
from domaincheck import CheckError

wl.VM_NAME_RETRY_DELAY = 0
client = wl.app.test_client()
S = {}
fails = 0
def check(name, cond):
    global fails
    print(("PASS " if cond else "FAIL ") + name); fails += (not cond)

class FakeChecker:
    """Stands in for the real existence check, so the tests never touch the internet."""
    def __init__(s): s.taken = set(); s.error = None; s.asked = []
    def check(s, d):
        s.asked.append(d)
        if s.error: raise CheckError(s.error)
        return {"available": d not in s.taken, "source": "fake"}

def reset(**kw):
    S.clear()
    S.update(plan="domain-com-annual", sub_state="ACTIVE", paid=1,
             fields={"domain_name": "shop.com", "domain_consent": "2026-11-14T10:00:00Z"})
    S.update(kw)
    for f in (REGFILE, REGFILE + ".lock"):
        if os.path.exists(f): os.remove(f)
    S["chk"] = FakeChecker()
    wl._registrar = rg.FakeRegistrar(REGFILE, S["chk"])

wl.kb_get = lambda path: [{"subscriptions": [{"subscriptionId": "sub-1", "planName": S["plan"]}]}] if path.endswith("/bundles") else None
wl.get_subscription = lambda sid: {"accountId": "acc-1", "planName": S["plan"], "state": S["sub_state"]}
wl.get_custom_fields = lambda sid: dict(S["fields"])
wl.paid_invoice_count = lambda a, s: S["paid"]
def set_field(sid, n, v): S["fields"][n] = v
wl.set_field = set_field
def fire(): return client.post("/killbill-webhook", json={"eventType": "INVOICE_PAYMENT_SUCCESS", "accountId": "acc-1", "objectId": "pay-1"})
def registry(): return json.load(open(REGFILE)) if os.path.exists(REGFILE) else {}

reset(); r = fire(); j = r.get_json()
check("fake mode registers after payment", r.status_code == 200 and j["results"][0]["status"] == "registered" and j["registrar"] == "fake")
rec = registry().get("shop.com")
check("registration is only a line in the local file", rec and rec["fake"] is True and rec["cost_cents"] == 1199 and rec["consent"] == "2026-11-14T10:00:00Z")
check("existence was checked first", S["chk"].asked == ["shop.com"])
check("fields recorded", S["fields"]["domain_status"] == "registered" and S["fields"]["domain_paid_count"] == "1"
      and S["fields"]["domain_registration_id"].startswith("fake-") and S["fields"]["domain_expires"] == rec["expires"])
S["chk"].asked.clear(); r = fire()
check("repeat event is a no-op", r.get_json()["results"][0]["status"] == "already-processed" and S["chk"].asked == [])

reset(); S["chk"].taken.add("shop.com"); j = fire().get_json()
check("name that exists on the internet is NOT registered", j["results"][0]["status"] == "needs-review" and registry() == {} and S["fields"]["domain_status"] == "needs-review")

reset(); S["chk"].error = "registry down"; r = fire()
check("check failure -> 500 so Kill Bill retries, nothing registered", r.status_code == 500 and registry() == {})
S["chk"].error = None; r = fire()
check("retry then registers", r.status_code == 200 and "shop.com" in registry())

reset(); wl._registrar.register("shop.com", "x", "kb-other-order"); j = fire().get_json()
check("name already in the fake registry (other order): needs-review", j["results"][0]["status"] == "needs-review")

reset(); wl._registrar.register("shop.com", "x", "kb-sub-1"); S["chk"].taken.add("shop.com"); j = fire().get_json()
check("crash recovery: this order's own registration is recognised", j["results"][0]["status"] == "registered" and S["fields"]["domain_status"] == "registered")

reset(paid=0); j = fire().get_json()
check("no paid invoice: nothing registered", j["results"][0]["status"] == "waiting-for-payment" and registry() == {} and S["chk"].asked == [])
reset(sub_state="CANCELLED"); j = fire().get_json()
check("cancelled subscription skipped", j["results"][0]["status"] == "skipped" and registry() == {})
reset(fields={"domain_name": "evil.org", "domain_consent": "x"}); j = fire().get_json()
check("extension must match plan", j["results"][0]["status"] == "needs-review" and registry() == {})
reset(fields={"domain_name": "a.com/../x", "domain_consent": "x"}); j = fire().get_json()
check("garbage name refused", j["results"][0]["status"] == "needs-review" and S["chk"].asked == [])
for plan, name, cost in (("domain-net-annual", "shop.net", 1399), ("domain-eu-annual", "shop.eu", 899)):
    reset(plan=plan, fields={"domain_name": name, "domain_consent": "x"}); j = fire().get_json()
    check(f"{name} registered (fake cost {cost})", j["results"][0]["status"] == "registered" and registry()[name]["cost_cents"] == cost)

# renewal
reset(paid=2, fields={"domain_name": "shop.com", "domain_consent": "x", "domain_paid_count": "1", "domain_status": "registered"})
wl._registrar.register("shop.com", "x", "kb-sub-1")
with wl._registrar._store() as d: d["shop.com"]["expires"] = "2026-12-01"
j = fire().get_json()
check("second paid invoice renews once", j["results"][0]["status"] == "renewed" and registry()["shop.com"]["expires"] == "2027-12-01" and S["fields"]["domain_paid_count"] == "2")
j = fire().get_json()
check("no double renewal", j["results"][0]["status"] == "already-processed" and registry()["shop.com"]["expires"] == "2027-12-01")
reset(paid=2, fields={"domain_name": "gone.com", "domain_consent": "x", "domain_paid_count": "1"}); j = fire().get_json()
check("renewal of an unknown domain: needs-review", j["results"][0]["status"] == "needs-review")

reset(plan="compute-vm-basic"); j = fire().get_json()
check("VM plan ignored by domain handler", j["status"] == "ignored")
reset(); r = client.post("/killbill-webhook", json={"eventType": "SUBSCRIPTION_CREATION", "objectId": "sub-1", "accountId": "acc-1"})
check("domain subscription creation does not provision a VM", r.get_json()["status"] == "ignored")

# registrar factory
check("default registrar is fake", isinstance(rg.make_registrar({"REGISTRY_FILE": REGFILE, "DOMAIN_CHECK": "rdap"}), rg.FakeRegistrar))
try: rg.make_registrar({"REGISTRAR": "godaddy"}); ok = False
except RuntimeError: ok = True
check("REGISTRAR=godaddy without a token refuses to start", ok)
try: rg.make_registrar({"REGISTRAR": "nonsense"}); ok = False
except RuntimeError: ok = True
check("unknown REGISTRAR refused", ok)
g = rg.make_registrar({"REGISTRAR": "godaddy", "GODADDY_TOKEN": "t", "DOMAIN_CHECK": "godaddy"})
check("godaddy mode builds the real registrar", isinstance(g, rg.GoDaddyRegistrar) and g.max_cost["eu"] == 2000)

# paid_invoice_count real logic
src = open(os.path.join(HERE, "..", "webhook", "webhook_listener.py")).read()
ns = {}
inv = [{"balance": 0, "items": [{"subscriptionId": "s", "amount": 18}]},
       {"balance": 18, "items": [{"subscriptionId": "s", "amount": 18}]},
       {"balance": 0, "items": [{"subscriptionId": "s", "amount": 0}]},
       {"balance": 0, "items": [{"subscriptionId": "other", "amount": 18}]}]
ns["kb_get"] = lambda p: inv
exec(src[src.index("def paid_invoice_count"):src.index("def record_server_id")], ns)
check("paid_invoice_count counts only paid charged invoices", ns["paid_invoice_count"]("a", "s") == 1)
print("FAILED" if fails else "ALL PASS"); sys.exit(1 if fails else 0)
