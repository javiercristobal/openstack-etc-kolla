import os, sys, types, re
os.environ.update(SECRET_KEY="s", KB_ADMIN_PASSWORD="x", KB_API_KEY="k", KB_API_SECRET="s",
                  BT_MERCHANT_ID="m", BT_PUBLIC_KEY="p", BT_PRIVATE_KEY="q", SESSION_COOKIE_SECURE="0",
                  DOMAIN_CHECK="rdap")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "site"))
try:
    import braintree  # noqa
except ImportError:
    bt = types.ModuleType("braintree")
    class _E(Exception): pass
    bt.Configuration = lambda *a, **k: None
    bt.Environment = types.SimpleNamespace(Sandbox="sandbox", Production="production")
    bt.BraintreeGateway = lambda *a, **k: types.SimpleNamespace(customer=None)
    bt.exceptions = types.SimpleNamespace(NotFoundError=_E)
    sys.modules["braintree"] = bt
import app as site
from kb import KillBillError
from domaincheck import CheckError

class FakeKB:
    def __init__(s): s.calls = []; s.fail = None; s.fields = {}
    def client_token(s): return "tok"
    def create_account(s, n, e, k): s.calls.append("account"); return "11111111-1111-1111-1111-111111111111"
    def add_card(s, *a): s.calls.append("card")
    def create_subscription(s, a, plan): s.calls.append(("sub", plan)); return "22222222-2222-2222-2222-222222222222"
    def tag_vm_name(s, sid, n): s.calls.append(("vm", n))
    def add_custom_fields(s, sid, f): s.calls.append(("fields", f))
    def get_subscription(s, sid): return {"state": "ACTIVE", "planName": s.plan}
    def get_custom_fields(s, sid): return s.fields
class FakeBT:
    def ensure_customer(s, *a): pass
class FakeGD:
    """Stands in for the real existence check (RDAP / GoDaddy)."""
    avail = {"available": True}; err = None; asked = []
    def check(s, d):
        s.asked.append(d)
        if s.err: raise s.err
        return {**s.avail, "source": "fake"}
fkb = FakeKB(); fgd = FakeGD()
fkb.in_use = set()
fkb.domain_in_use = lambda d: d in fkb.in_use
site.kb = fkb; site.bt = FakeBT(); site.checker = fgd
c = site.app.test_client()
fails = 0
def check(n, cond):
    global fails
    print(("PASS " if cond else "FAIL ") + n); fails += (not cond)

def csrf():
    c.get("/domain")
    with c.session_transaction() as s: return s["csrf"]

r = c.get("/domain"); html = r.get_data(as_text=True)
check("domain page lists .com .net .eu", r.status_code==200 and all(f".{t}" in html for t in ("com","net","eu")))
check("nav shows Domains", 'href="/domain"' in html)
t = csrf()
r = c.post("/domain/search", data={"csrf_token": t, "label": "Shop", "tld": "com"})
check("available name -> order page", r.status_code==200 and "shop.com is available" in r.get_data(as_text=True))
r = c.post("/domain/search", data={"csrf_token": t, "label": "shop.NET ", "tld": "net"})
check("typed extension is stripped", "shop.net is available" in r.get_data(as_text=True))
r = c.post("/domain/search", data={"csrf_token": t, "label": "x", "tld": "org"})
check("unsupported extension rejected", r.status_code==400)
r = c.post("/domain/search", data={"csrf_token": t, "label": "bad_name!", "tld": "com"})
check("bad label rejected", r.status_code==400)
r = c.post("/domain/search", data={"label": "shop", "tld": "com"})
check("search needs CSRF", r.status_code==400)
fgd.avail = {"available": False}
r = c.post("/domain/search", data={"csrf_token": t, "label": "shop", "tld": "com"})
check("taken name says so", "already taken" in r.get_data(as_text=True) and "is available" not in r.get_data(as_text=True))
fgd.avail = {"available": True}; fgd.err = CheckError("down")
r = c.post("/domain/search", data={"csrf_token": t, "label": "shop", "tld": "com"})
check("registry unreachable -> friendly error, never \"available\"", r.status_code==502 and "check that name" in r.get_data(as_text=True))
fgd.err = None

order = {"label": "shop", "tld": "eu", "name": "Ann Lee", "email": "ann@example.com",
         "payment_method_nonce": "nonce", "terms": "on"}
fkb.calls.clear()
r = c.post("/domain/order", data={**order, "csrf_token": t})
loc = r.headers.get("Location", "")
check("order redirects to status", r.status_code==303 and loc.endswith("/order/22222222-2222-2222-2222-222222222222"))
check("eu plan + fields written",
      ("sub","domain-eu-annual") in fkb.calls and any(isinstance(x, tuple) and x[0]=="fields" and x[1]["domain_name"]=="shop.eu" and re.match(r"\d{4}-\d\d-\d\dT[\d:]+Z", x[1]["domain_consent"]) for x in fkb.calls))
t = csrf(); fkb.calls.clear()
r = c.post("/domain/order", data={**order, "csrf_token": t, "terms": ""})
check("terms required, nothing created", r.status_code==400 and fkb.calls==[])
r = c.post("/domain/order", data={**order, "csrf_token": t, "payment_method_nonce": ""})
check("card required, nothing created", r.status_code==400 and fkb.calls==[])
r = c.post("/domain/order", data={**order, "csrf_token": t, "tld": "org"})
check("tampered extension refused", r.status_code==400 and fkb.calls==[])
fgd.avail = {"available": False}
r = c.post("/domain/order", data={**order, "csrf_token": t})
check("name taken meanwhile: not charged", r.status_code==409 and fkb.calls==[])
fgd.avail = {"available": True}
r = c.post("/domain/order", data={**order, "csrf_token": "bad"})
check("order needs CSRF", r.status_code==400)

# status pages
fkb.plan = "domain-com-annual"
for fields, text in (({"domain_name":"shop.com"}, "Registering your domain"),
                     ({"domain_name":"shop.com","domain_status":"registered","domain_expires":"2027-11-09T00:00:00Z"}, "shop.com is registered"),
                     ({"domain_name":"shop.com","domain_status":"needs-review"}, "We need to check")):
    fkb.fields = fields
    h = c.get("/order/22222222-2222-2222-2222-222222222222").get_data(as_text=True)
    check("status: " + text, text in h)
check("expiry date shown", "2027-11-09" in c.get("/order/22222222-2222-2222-2222-222222222222").get_data(as_text=True) or True)
fkb.fields = {"domain_name":"shop.com","domain_status":"registered","domain_expires":"2027-11-09T00:00:00Z"}
check("expiry shown", "2027-11-09" in c.get("/order/22222222-2222-2222-2222-222222222222").get_data(as_text=True))

# VM flow still works
fkb.plan = "compute-vm-medium"; fkb.fields = {"vm_name": "box-22222222", "openstack_server_id": "srv", "floating_ip": "1.2.3.4"}
check("VM status unchanged", "Your VM is ready" in c.get("/order/22222222-2222-2222-2222-222222222222").get_data(as_text=True))
c.get("/")
with c.session_transaction() as s: t = s["csrf"]
fkb.calls.clear()
r = c.post("/order", data={"csrf_token": t, "name": "Ann Lee", "email": "ann@example.com", "vm_name": "box",
                           "plan": "compute-vm-large", "payment_method_nonce": "n"})
check("VM order still works", r.status_code==303 and ("sub","compute-vm-large") in fkb.calls and ("vm","box-22222222") in fkb.calls)
check("VM form loads", c.get("/").status_code==200)

# a name already ordered by someone else in Kill Bill is taken
t = csrf(); fkb.in_use = {"held.com"}
r = c.post("/domain/search", data={"csrf_token": t, "label": "held", "tld": "com"})
check("name held by an active order is taken", "already taken" in r.get_data(as_text=True))
fkb.in_use = set()
fkb.domain_in_use = lambda d: (_ for _ in ()).throw(site.KillBillError("down", status=500))
r = c.post("/domain/search", data={"csrf_token": t, "label": "shop", "tld": "com"})
check("Kill Bill lookup failure -> error, not 'available'", r.status_code == 502 and "is available" not in r.get_data(as_text=True))
fkb.domain_in_use = lambda d: d in fkb.in_use
fgd.asked.clear()
c.post("/domain/search", data={"csrf_token": t, "label": "x", "tld": "xyz"})
check("unsupported extension never reaches the checker", fgd.asked == [])
check("domains pages always on (no token needed)", c.get("/domain").status_code == 200 and 'href="/domain"' in c.get("/").get_data(as_text=True))
print("FAILED" if fails else "ALL PASS"); sys.exit(1 if fails else 0)
