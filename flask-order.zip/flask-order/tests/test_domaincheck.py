import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "site"))
import requests
import domaincheck as dc
from godaddy import GoDaddyError

fails = 0
def check(name, cond):
    global fails
    print(("PASS " if cond else "FAIL ") + name); fails += (not cond)

class Resp:
    def __init__(s, code, body=None): s.status_code, s._b = code, body
    def json(s):
        if s._b is None: raise ValueError
        return s._b

class Sess:
    def __init__(s, routes): s.routes, s.headers, s.urls = routes, {}, []
    def get(s, url, **kw):
        s.urls.append(url)
        r = s.routes.get(url)
        if isinstance(r, Exception): raise r
        return r if r is not None else Resp(404)

BOOT = {"services": [[["com", "net"], ["https://rdap.verisign.com/com/v1/"]],
                     [["eu"], ["http://insecure.example/", "https://rdap.eu.example/"]]]}
routes = {dc.BOOTSTRAP_URL: Resp(200, BOOT),
          "https://rdap.verisign.com/com/v1/domain/google.com": Resp(200, {}),
          "https://rdap.eu.example/domain/taken.eu": Resp(200, {}),
          "https://rdap.eu.example/domain/slow.eu": Resp(503),
          "https://rdap.eu.example/domain/boom.eu": requests.ConnectionError("no route")}
s = Sess(routes); c = dc.RdapChecker(session=s)
check("registered .com -> not available", c.check("google.com") == {"available": False, "source": "rdap", "detail": "registered"})
check("404 -> available", c.check("zzqx-no-such-name-9.com")["available"] is True)
check(".eu uses the https registry from the IANA list", c.check("taken.eu")["available"] is False and "https://rdap.eu.example/domain/taken.eu" in s.urls)
check("the IANA list is fetched once", s.urls.count(dc.BOOTSTRAP_URL) == 1)
for d, label in (("slow.eu", "HTTP 503"), ("boom.eu", "network error")):
    try: c.check(d); ok = False
    except dc.CheckError: ok = True
    check(f"{label} -> CheckError, never 'available'", ok)
for bad in ("example.org", "a b.com", "../x.com", "x.com/evil", "-bad.com", "nodot"):
    try: c.check(bad); ok = False
    except dc.CheckError: ok = True
    check(f"refuses {bad!r}", ok)
s2 = Sess({dc.BOOTSTRAP_URL: requests.ConnectionError("down")}); c2 = dc.RdapChecker(session=s2)
c2.check("fresh.com")
check("IANA list unreachable: falls back to rdap.org", s2.urls[-1] == "https://rdap.org/domain/fresh.com")

class GD:
    def __init__(s, r): s.r = r
    def check_availability(s, d):
        if isinstance(s.r, Exception): raise s.r
        return s.r
check("GoDaddy checker passes the answer through", dc.GoDaddyChecker(GD({"available": True, "definitive": True})).check("a.com")["available"] is True)
for r, label in ((GD({"available": True, "definitive": False}), "not definitive"), (GD(GoDaddyError("403", status=403)), "API error")):
    try: dc.GoDaddyChecker(r).check("a.com"); ok = False
    except dc.CheckError: ok = True
    check(f"GoDaddy {label} -> CheckError", ok)
check("auto without token = RDAP", isinstance(dc.make_checker({}), dc.RdapChecker))
check("auto with token = GoDaddy", isinstance(dc.make_checker({"GODADDY_TOKEN": "t"}), dc.GoDaddyChecker))
try: dc.make_checker({"DOMAIN_CHECK": "godaddy"}); ok = False
except RuntimeError: ok = True
check("DOMAIN_CHECK=godaddy needs a token", ok)
print("FAILED" if fails else "ALL PASS"); sys.exit(1 if fails else 0)
