"""
Domain registrars for the webhook listener, behind one interface.

  REGISTRAR=fake      (default) A registration is only written to a local file
                      (REGISTRY_FILE). Nothing is bought, nothing leaves the machine, nothing costs
                      money. Existence is still checked for real (domaincheck.py), so a name that
                      already exists on the internet is refused.
  REGISTRAR=godaddy   The real GoDaddy v3 API (godaddy.py). Needs GODADDY_TOKEN. Spends real money.

Both return the same dicts: {"registration_id", "cost_cents", "expires"} where expires is YYYY-MM-DD.
"""

import fcntl
import hashlib
import json
import os
import tempfile
from contextlib import contextmanager
from datetime import date, datetime, timezone

from domaincheck import CheckError, make_checker
from godaddy import GoDaddy, GoDaddyError, GoDaddyPending

FAKE_COSTS_CENTS = {"com": 1199, "net": 1399, "eu": 899}   # what the fake registrar "charges" us


class RegistrarError(Exception):
    def __init__(self, message, transient=False):
        super().__init__(message)
        self.transient = transient


def _plus_year(d: date) -> date:
    try:
        return d.replace(year=d.year + 1)
    except ValueError:  # 29 February
        return d.replace(year=d.year + 1, day=28)


def _parse(day: str) -> date:
    y, m, d = (int(x) for x in str(day)[:10].split("-"))
    return date(y, m, d)


class FakeRegistrar:
    mode = "fake"

    def __init__(self, path, checker):
        self.path, self.checker = path, checker

    @contextmanager
    def _store(self):
        """Locked read-modify-write of the JSON registry."""
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        with open(self.path + ".lock", "w") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            data = self._load()
            yield data
            fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path) or ".")
            with os.fdopen(fd, "w") as fh:
                json.dump(data, fh, indent=2, sort_keys=True)
            os.replace(tmp, self.path)

    def _load(self):
        """The registry as a dict. A missing or empty file means no registrations yet."""
        try:
            with open(self.path) as fh:
                text = fh.read()
        except FileNotFoundError:
            return {}
        if not text.strip():
            return {}
        return json.loads(text)

    def _read(self):
        return self._load()

    @staticmethod
    def _id(key):
        return "fake-" + hashlib.sha1(key.encode()).hexdigest()[:12]

    def owns(self, domain, key):
        rec = self._read().get(domain)
        if rec and rec["registration_id"] == self._id(key):
            return {"registration_id": rec["registration_id"], "cost_cents": rec["cost_cents"],
                    "expires": rec["expires"]}
        return None

    def get(self, domain):
        rec = self._read().get(domain)
        return {"expires": rec["expires"]} if rec else None

    def available(self, domain):
        """Not in the fake registry AND does not exist on the real internet."""
        if domain in self._read():
            return False
        try:
            return self.checker.check(domain)["available"]
        except CheckError as exc:
            raise RegistrarError(str(exc), transient=True) from exc

    def register(self, domain, consent, key):
        tld = domain.rpartition(".")[2]
        cost = FAKE_COSTS_CENTS.get(tld)
        if cost is None:
            raise RegistrarError(f".{tld} is not supported")
        with self._store() as data:
            if domain in data:
                raise RegistrarError(f"{domain} is already in the registry")
            expires = _plus_year(date.today()).strftime("%Y-%m-%d")
            data[domain] = {"registration_id": self._id(key), "cost_cents": cost, "expires": expires,
                            "registered_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                            "consent": consent, "auto_renew": False, "fake": True}
        return {"registration_id": self._id(key), "cost_cents": cost, "expires": expires}

    def renew(self, domain):
        with self._store() as data:
            if domain not in data:
                raise RegistrarError(f"{domain} is not in the registry")
            data[domain]["expires"] = _plus_year(_parse(data[domain]["expires"])).strftime("%Y-%m-%d")
            return {"registration_id": data[domain]["registration_id"], "cost_cents": data[domain]["cost_cents"],
                    "expires": data[domain]["expires"]}

    def set_auto_renew_off(self, domain):
        with self._store() as data:
            if domain in data:
                data[domain]["auto_renew"] = False


class GoDaddyRegistrar:
    mode = "godaddy"

    def __init__(self, token, checker, base_url="https://api.godaddy.com", max_cost_cents=None):
        self.gd = GoDaddy(token, base_url=base_url)
        self.checker = checker
        self.max_cost = max_cost_cents or {"com": 2500, "net": 2500, "eu": 2000}

    @staticmethod
    def _wrap(exc):
        return RegistrarError(str(exc), transient=getattr(exc, "transient", False))

    def _expires(self, domain):
        rec = self.gd.get_domain(domain) or {}
        return str(rec.get("expires", ""))[:10] or None

    def owns(self, domain, key):
        try:
            rec = self.gd.get_domain(domain)
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc
        return {"registration_id": None, "cost_cents": None, "expires": str(rec.get("expires", ""))[:10]} if rec else None

    def get(self, domain):
        try:
            rec = self.gd.get_domain(domain)
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc
        return {"expires": str(rec.get("expires", ""))[:10]} if rec else None

    def available(self, domain):
        try:
            return self.checker.check(domain)["available"]
        except CheckError as exc:
            raise RegistrarError(str(exc), transient=True) from exc

    def register(self, domain, consent, key):
        tld = domain.rpartition(".")[2]
        try:
            quote = self.gd.quote(domain, 1)
            limit = self.max_cost.get(tld)
            if limit is None or quote["currency"] != "USD" or quote["price_cents"] > limit:
                raise RegistrarError(
                    f"GoDaddy price {quote['price_cents']} {quote['currency']} is above the limit for .{tld}")
            reg_id = self.gd.register(quote, domain, 1, consent, [a["type"] for a in quote["agreements"]],
                                      idempotency_key=key)
            self.gd.wait_for_registration(reg_id, timeout=100)
            return {"registration_id": reg_id, "cost_cents": quote["price_cents"], "expires": self._expires(domain)}
        except GoDaddyPending as exc:
            raise RegistrarError(str(exc), transient=True) from exc
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc

    def renew(self, domain):
        try:
            self.gd.renew(domain, 1)
            return {"registration_id": None, "cost_cents": None, "expires": self._expires(domain)}
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc

    def set_auto_renew_off(self, domain):
        try:
            self.gd.set_auto_renew(domain, False)
        except GoDaddyError as exc:
            raise self._wrap(exc) from exc


def make_registrar(env=None):
    env = os.environ if env is None else env
    mode = env.get("REGISTRAR", "fake").strip().lower()
    checker = make_checker(env)
    if mode == "fake":
        return FakeRegistrar(env.get("REGISTRY_FILE", "/var/lib/kb-webhook/fake_registry.json"), checker)
    if mode == "godaddy":
        token = env.get("GODADDY_TOKEN", "").strip()
        if not token:
            raise RuntimeError("REGISTRAR=godaddy needs GODADDY_TOKEN")
        limits = {}
        for item in env.get("DOMAIN_MAX_COST_CENTS", "").split(","):
            if "=" in item:
                k, v = item.split("=", 1)
                limits[k.strip()] = int(v)
        return GoDaddyRegistrar(token, checker, env.get("GODADDY_BASE_URL", "https://api.godaddy.com"), limits or None)
    raise RuntimeError("REGISTRAR must be 'fake' or 'godaddy'")
