"""
VM order site.

Collects a VM order and a card (via Braintree Drop-in, so the card number goes
straight to Braintree and never touches this server), then hands the order to
Kill Bill:

    account -> card (nonce) -> subscription -> vm_name tag

Kill Bill then fires SUBSCRIPTION_CREATION and webhook_listener.py on the
OpenStack controller creates the VM. This site only reads progress back.

Required environment: SECRET_KEY, KB_ADMIN_PASSWORD, KB_API_KEY, KB_API_SECRET
(see deploy/kb-order.env.example).
"""

import hmac
import logging
import os
import re
import secrets
import uuid
from datetime import datetime, timezone

import click
from flask import Flask, abort, redirect, render_template, request, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

from bt import BraintreeCustomers, BraintreeError
from domaincheck import CheckError, make_checker
from godaddy import normalize_label, valid_label
from kb import KillBill, KillBillError

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("flask-killbill")

_REQUIRED = ("SECRET_KEY", "KB_ADMIN_PASSWORD", "KB_API_KEY", "KB_API_SECRET",
             "BT_MERCHANT_ID", "BT_PUBLIC_KEY", "BT_PRIVATE_KEY")
_missing = [name for name in _REQUIRED if not os.environ.get(name)]
if _missing:
    raise RuntimeError("Missing required environment variable(s): " + ", ".join(_missing))

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)  # behind nginx
app.config.update(
    SECRET_KEY=os.environ["SECRET_KEY"],
    # Set SESSION_COOKIE_SECURE=0 only while testing over plain http.
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "1") == "1",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SITE_NAME=os.environ.get("SITE_NAME", "cloud.lab"),
    SHOW_TEST_CARD_HINT=os.environ.get("SHOW_TEST_CARD_HINT", "1") == "1",
)

kb = KillBill(
    base_url=os.environ.get("KB_BASE_URL", "http://127.0.0.1:8080"),
    user=os.environ.get("KB_ADMIN_USER", "admin"),
    password=os.environ["KB_ADMIN_PASSWORD"],
    api_key=os.environ["KB_API_KEY"],
    api_secret=os.environ["KB_API_SECRET"],
    timeout=float(os.environ.get("KB_TIMEOUT", "20")),  # seconds
)

bt = BraintreeCustomers(
    environment=os.environ.get("BT_ENVIRONMENT", "sandbox"),
    merchant_id=os.environ["BT_MERCHANT_ID"],
    public_key=os.environ["BT_PUBLIC_KEY"],
    private_key=os.environ["BT_PRIVATE_KEY"],
)

# Only set this if the plugin rejects orders without it (CARD, PAYPAL or ACH).
BT_PAYMENT_METHOD_TYPE = os.environ.get("BT_PAYMENT_METHOD_TYPE", "").strip() or None

# Plans offered on the form, keyed by catalog plan name. "flavor" is only shown to
# the customer: the listener on the controller decides the real OpenStack flavor
# (VM_PLAN_FLAVORS in webhook_listener.py), so keep the two in step.
PLANS = {
    "compute-vm-basic": {"title": "Basic", "price": "$10 per month", "flavor": "m1.mini"},
    "compute-vm-medium": {"title": "Medium", "price": "$20 per month", "flavor": "m1.medium"},
    "compute-vm-large": {"title": "Large", "price": "$30 per month", "flavor": "m1.large"},
}
DEFAULT_PLAN = "compute-vm-basic"

# Domain extensions offered. "plan" is the Kill Bill plan (billed every year);
# "price" is only the text shown to the customer, so keep it equal to the catalog.
# The webhook listener maps the same plans to extensions (DOMAIN_PLANS).
DOMAIN_TLDS = {
    "com": {"plan": "domain-com-annual", "price": "$18 per year"},
    "net": {"plan": "domain-net-annual", "price": "$20 per year"},
    "eu": {"plan": "domain-eu-annual", "price": "$14 per year",
           "note": "A .eu domain can only be registered by a person or company in the EU, EEA or "
                   "Iceland, Liechtenstein or Norway."},
}
DOMAIN_PLAN_TLD = {v["plan"]: k for k, v in DOMAIN_TLDS.items()}
DOMAIN_TERMS_URL = "https://www.godaddy.com/legal/agreements/domain-name-registration-agreement"

# Does the name already exist? RDAP by default, GoDaddy's availability API if GODADDY_TOKEN is set.
# Registration itself happens later, in the webhook, and is fake unless REGISTRAR=godaddy there.
checker = make_checker()

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
VM_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,28}[a-z0-9]$")  # 3 to 30 characters


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def csrf_token() -> str:
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token
app.jinja_env.globals["domains_enabled"] = lambda: True


def check_csrf() -> None:
    sent = request.form.get("csrf_token", "")
    expected = session.get("csrf", "")
    if not expected or not hmac.compare_digest(sent, expected):
        log.warning("CSRF check failed (if this is plain http, set SESSION_COOKIE_SECURE=0)")
        abort(400)


def clean_form() -> dict:
    return {
        "name": request.form.get("name", "").strip(),
        "email": request.form.get("email", "").strip().lower(),
        "vm_name": request.form.get("vm_name", "").strip().lower(),
        "plan": request.form.get("plan", "").strip(),
        "nonce": request.form.get("payment_method_nonce", "").strip(),
    }


def validate(form: dict) -> list:
    errors = []
    if not 2 <= len(form["name"]) <= 100:
        errors.append("Enter your full name.")
    if len(form["email"]) > 254 or not EMAIL_RE.match(form["email"]):
        errors.append("Enter a valid email address.")
    if not VM_NAME_RE.match(form["vm_name"]):
        errors.append("Name the VM with 3 to 30 lowercase letters, numbers or hyphens, "
                      "starting and ending with a letter or number.")
    if form["plan"] not in PLANS:
        errors.append("Choose a plan.")
    if not form["nonce"]:
        errors.append("Enter your card details.")
    return errors


def render_order(form=None, errors=None, status=200):
    try:
        token = kb.client_token()
    except KillBillError as exc:
        log.error("Could not get a Braintree client token: %s %s", exc, exc.body)
        return render_template(
            "error.html",
            title="Ordering is unavailable",
            message="The payment service isn't responding. Try again in a few minutes.",
        ), 503
    return render_template(
        "order.html",
        client_token=token,
        plans=PLANS,
        selected_plan=(form or {}).get("plan") if (form or {}).get("plan") in PLANS else DEFAULT_PLAN,
        form=form or {},
        errors=errors or [],
    ), status


def payment_unavailable():
    return render_template(
        "error.html",
        title="Ordering is unavailable",
        message="The payment service isn't responding. Try again in a few minutes.",
    ), 503


def ensure_account_and_card(form):
    """Shared by VM and domain orders. Returns (account_id, None) or (None, (errors, status))."""
    pending = session.get("pending") or {}
    if pending.get("email") != form["email"]:
        pending = {}
    try:
        account_id = pending.get("account_id")
        if not account_id:
            account_id = kb.create_account(
                form["name"], form["email"], f"order-{uuid.uuid4().hex[:12]}"
            )
            pending = {"account_id": account_id, "email": form["email"], "card": False}
            session["pending"] = pending
    except KillBillError as exc:
        log.error("Account creation failed: %s %s", exc, exc.body)
        return None, (["We couldn't create your account. Try again in a minute."], 502)

    if not pending.get("card"):
        try:
            # The plugin needs the Braintree customer to exist already; its id is
            # the Kill Bill account id.
            bt.ensure_customer(account_id, form["name"], form["email"])
        except BraintreeError as exc:
            log.error("Braintree customer failed for account %s: %s", account_id, exc)
            return None, (["We couldn't set up your payment profile. Try again in a minute."], 502)
        try:
            kb.add_card(account_id, form["nonce"], account_id, BT_PAYMENT_METHOD_TYPE)
        except KillBillError as exc:
            log.error("Card not saved for account %s: %s %s", account_id, exc, exc.body)
            return None, (["We couldn't save that card. Check the details or try another card."], 402)
        pending["card"] = True
        session["pending"] = pending
    return account_id, None


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if not request.path.startswith("/static/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


@app.errorhandler(400)
def bad_request(_exc):
    return render_template(
        "error.html",
        title="This form has expired",
        message="Reload the page and submit the order again.",
    ), 400


@app.errorhandler(404)
def not_found(_exc):
    return render_template(
        "error.html",
        title="Page not found",
        message="Check the address, or start a new order.",
    ), 404


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
@app.get("/")
def order_form():
    # /?plan=compute-vm-large pre-selects a plan, handy for links from a price page.
    return render_order({"plan": request.args.get("plan", "")})


@app.post("/order")
def order_submit():
    check_csrf()
    form = clean_form()
    errors = validate(form)
    if errors:
        return render_order(form, errors, 400)

    # If an earlier attempt got as far as creating the account (for example the
    # card was declined), it is reused instead of leaving orphans behind.
    account_id, failure = ensure_account_and_card(form)
    if failure:
        return render_order(form, *failure)

    try:
        subscription_id = kb.create_subscription(account_id, form["plan"])
    except KillBillError as exc:
        log.error("Subscription failed for account %s: %s %s", account_id, exc, exc.body)
        return render_order(
            form, ["Your card is saved, but we couldn't place the order. Try again in a minute."], 502
        )

    # The listener boots the VM under this exact name. The subscription id keeps
    # it unique, because the listener reuses an existing server with the same name.
    vm_name = f"{form['vm_name']}-{subscription_id[:8]}"
    try:
        kb.tag_vm_name(subscription_id, vm_name)
    except KillBillError as exc:
        # Not fatal: the listener falls back to vm-<subscription id>.
        log.error("Could not tag vm_name on %s: %s %s", subscription_id, exc, exc.body)

    session.pop("pending", None)
    session.pop("csrf", None)
    log.info("Order placed: account=%s subscription=%s vm=%s", account_id, subscription_id, vm_name)
    return redirect(url_for("order_status", subscription_id=subscription_id), 303)


@app.get("/order/<subscription_id>")
def order_status(subscription_id):
    try:
        uuid.UUID(subscription_id)
    except ValueError:
        abort(404)
    try:
        sub = kb.get_subscription(subscription_id)
        fields = kb.get_custom_fields(subscription_id)
    except KillBillError as exc:
        if exc.status == 404:
            abort(404)
        log.error("Status lookup failed for %s: %s %s", subscription_id, exc, exc.body)
        return render_template(
            "error.html",
            title="Status is unavailable",
            message="We can't read the order status right now. Reload in a minute.",
        ), 503

    if sub.get("planName") in DOMAIN_PLAN_TLD:
        return domain_status_page(subscription_id, sub, fields)

    server_id = fields.get("openstack_server_id")
    floating_ip = fields.get("floating_ip")
    if sub.get("state") not in (None, "ACTIVE"):
        phase = "inactive"
    elif server_id and floating_ip:  # the listener records the IP last
        phase = "ready"
    else:
        phase = "pending"

    plan = PLANS.get(sub.get("planName"), {"title": sub.get("planName") or "Virtual machine", "price": ""})
    return render_template(
        "status.html",
        phase=phase,
        subscription_id=subscription_id,
        sub_state=sub.get("state"),
        plan=plan,
        vm_name=fields.get("vm_name"),
        server_id=server_id,
        floating_ip=floating_ip,
    )


# --------------------------------------------------------------------------
# Domain registration
# --------------------------------------------------------------------------
def split_domain(form):
    """Returns (label, tld, domain) from the posted search fields, or (None, tld, None)."""
    tld = form.get("tld", "").strip().lower().lstrip(".")
    label = normalize_label(form.get("label", ""), tld)
    if tld not in DOMAIN_TLDS or not valid_label(label):
        return None, tld, None
    return label, tld, f"{label}.{tld}"


def render_domain_search(form=None, errors=None, result=None, status=200):
    form = form or {}
    if result is None:
        return render_template("domain_search.html", tlds=DOMAIN_TLDS, form=form,
                               errors=errors or []), status
    try:
        token = kb.client_token()
    except KillBillError as exc:
        log.error("Could not get a Braintree client token: %s %s", exc, exc.body)
        return payment_unavailable()
    return render_template("domain_order.html", client_token=token, tlds=DOMAIN_TLDS, form=form,
                           errors=errors or [], result=result, terms_url=DOMAIN_TERMS_URL), status


def check_domain(domain):
    """Returns ({'available': bool, 'reason': str}, None) or (None, error message).

    A name is taken if it exists on the internet (registry or GoDaddy check) or if another
    active order in Kill Bill already holds it."""
    try:
        info = checker.check(domain)
    except CheckError as exc:
        log.error("Domain check failed for %s: %s", domain, exc)
        return None, "We couldn't check that name right now. Try again in a minute."
    if not info["available"]:
        return {"available": False, "reason": "exists"}, None
    try:
        if kb.domain_in_use(domain):
            return {"available": False, "reason": "ordered"}, None
    except KillBillError as exc:
        log.error("Could not look up existing orders for %s: %s %s", domain, exc, exc.body)
        return None, "We couldn't check that name right now. Try again in a minute."
    return {"available": True, "reason": None}, None


@app.get("/domain")
def domain_form():
    return render_domain_search({"tld": request.args.get("tld", "com")})


@app.post("/domain/search")
def domain_search():
    check_csrf()
    form = {"label": request.form.get("label", ""), "tld": request.form.get("tld", "com")}
    label, tld, domain = split_domain(form)
    if not domain:
        return render_domain_search(
            form, ["Enter a name with letters, numbers or hyphens, and choose .com, .net or .eu."], status=400
        )
    form = {"label": label, "tld": tld}
    info, problem = check_domain(domain)
    if problem:
        return render_domain_search(form, [problem], status=502)
    if not info["available"]:
        return render_domain_search(form, [f"{domain} is already taken. Try another name or extension."])
    return render_domain_search(form, result={"domain": domain, "tld": tld})


@app.post("/domain/order")
def domain_order():
    check_csrf()
    form = clean_form()
    form["label"] = request.form.get("label", "")
    form["tld"] = request.form.get("tld", "")
    form["terms"] = request.form.get("terms") == "on"
    label, tld, domain = split_domain(form)
    if not domain:
        return render_domain_search(
            {"label": form["label"], "tld": form["tld"]}, ["Search for a domain name first."], status=400
        )

    errors = []
    if not 2 <= len(form["name"]) <= 100:
        errors.append("Enter your full name.")
    if len(form["email"]) > 254 or not EMAIL_RE.match(form["email"]):
        errors.append("Enter a valid email address.")
    if not form["terms"]:
        errors.append("Accept the domain registration agreement to continue.")
    if not form["nonce"]:
        errors.append("Enter your card details.")
    form["label"] = label
    result = {"domain": domain, "tld": tld}
    if errors:
        return render_domain_search(form, errors, result, 400)

    # Check again right before charging: the name may have been taken meanwhile.
    info, problem = check_domain(domain)
    if problem:
        return render_domain_search(form, [problem], result, 502)
    if not info["available"]:
        return render_domain_search({"label": label, "tld": tld},
                                    [f"{domain} was just taken. Try another name."], status=409)

    account_id, failure = ensure_account_and_card(form)
    if failure:
        return render_domain_search(form, failure[0], result, failure[1])

    try:
        subscription_id = kb.create_subscription(account_id, DOMAIN_TLDS[tld]["plan"])
    except KillBillError as exc:
        log.error("Domain subscription failed for account %s: %s %s", account_id, exc, exc.body)
        return render_domain_search(
            form, ["Your card is saved, but we couldn't place the order. Try again in a minute."],
            result, 502)

    try:
        kb.add_custom_fields(subscription_id, {
            "domain_name": domain,
            "domain_consent": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        })
    except KillBillError as exc:
        # The listener refuses to register a domain without these two fields.
        log.error("Could not tag domain on %s: %s %s", subscription_id, exc, exc.body)

    session.pop("pending", None)
    session.pop("csrf", None)
    log.info("Domain order placed: account=%s subscription=%s domain=%s", account_id, subscription_id, domain)
    return redirect(url_for("order_status", subscription_id=subscription_id), 303)


def domain_status_page(subscription_id, sub, fields):
    status = (fields.get("domain_status") or "").lower()
    if sub.get("state") not in (None, "ACTIVE"):
        phase = "inactive"
    elif status == "registered":
        phase = "ready"
    elif status in ("failed", "needs-review"):
        phase = "problem"
    else:
        phase = "pending"
    tld = DOMAIN_PLAN_TLD.get(sub.get("planName"))
    return render_template(
        "status_domain.html",
        phase=phase,
        subscription_id=subscription_id,
        sub_state=sub.get("state"),
        plan=DOMAIN_TLDS.get(tld, {}),
        domain=fields.get("domain_name"),
        expires=(fields.get("domain_expires") or "")[:10],
    )


@app.get("/healthz")
def healthz():
    return "ok"


@app.cli.command("check")
def check_command():
    """Confirm Kill Bill is reachable and the Braintree plugin issues client tokens."""
    try:
        nodes = kb.nodes_info()
    except KillBillError as exc:
        raise click.ClickException(f"Kill Bill check failed: {exc} {exc.body or ''}")
    states = [
        p.get("state")
        for node in nodes
        for p in node.get("pluginsInfo", [])
        if p.get("pluginKey") == "braintree"
    ]
    click.echo(f"Kill Bill reachable. braintree plugin state: {states or 'not installed'}")
    try:
        token = kb.client_token()
    except KillBillError as exc:
        raise click.ClickException(f"Client token request failed: {exc} {exc.body or ''}")
    click.echo(f"Client token OK ({len(token)} characters).")
