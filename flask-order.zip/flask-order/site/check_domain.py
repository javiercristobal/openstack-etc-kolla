#!/usr/bin/env python3
"""Ask the same existence check the site uses:  python check_domain.py shop.com shop.net shop.eu

Uses DOMAIN_CHECK / GODADDY_TOKEN from the environment. Needs no other setting."""
import sys

from domaincheck import CheckError, make_checker

checker = make_checker()
for name in sys.argv[1:] or ["example.com"]:
    try:
        r = checker.check(name.strip().lower())
        print(f"{name}: {'AVAILABLE' if r['available'] else 'EXISTS'} ({r['source']}: {r['detail']})")
    except CheckError as exc:
        print(f"{name}: could not be checked: {exc}")
