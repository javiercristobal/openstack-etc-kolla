#!/usr/bin/env bash
# Run on the Flask VM from the unzipped flask-order directory:  sudo bash scripts/install-site.sh
# Copies the site into /opt/flask-killbill, keeps your venv and /etc/kb-order.env,
# installs requirements and restarts kb-order. Previous code is saved in /opt/flask-killbill.bak-<time>.
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
dest=/opt/flask-killbill
[ "$(id -u)" = 0 ] || { echo "Run with sudo"; exit 1; }
[ -d "$dest" ] || { echo "$dest not found"; exit 1; }
backup="$dest.bak-$(date +%Y%m%d-%H%M%S)"
rsync -a --exclude venv --exclude '__pycache__' "$dest"/ "$backup"/
rsync -a --exclude 'deploy/kb-order.env.example' "$here/site/" "$dest/"
# the service runs as www-data: every app file must be readable by it
find "$dest" -path "$dest/venv" -prune -o -type d -exec chmod a+rx {} + -o -type f -exec chmod a+r {} +
"$dest/venv/bin/pip" install -q -r "$dest/requirements.txt"
if ! grep -q '^GODADDY_TOKEN=.' /etc/kb-order.env; then
  echo "NOTE: GODADDY_TOKEN is not set in /etc/kb-order.env, so the Domains pages stay hidden."
  echo "      Add:  GODADDY_TOKEN=<read-only token>"
fi
systemctl restart kb-order
sleep 2
systemctl is-active kb-order
curl -fsS -o /dev/null -w "healthz: %{http_code}\n" http://127.0.0.1:8000/healthz
echo "Backup of the old code: $backup"
