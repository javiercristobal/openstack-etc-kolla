#!/usr/bin/env bash
# Run on the OpenStack controller from the unzipped flask-order directory:
#   sudo bash scripts/install-webhook.sh
# Copies the listener into /opt/kb-webhook, keeps /etc/kb-webhook.env, restarts kb-webhook.
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
dest=/opt/kb-webhook
[ "$(id -u)" = 0 ] || { echo "Run with sudo"; exit 1; }
[ -d "$dest" ] || { echo "$dest not found"; exit 1; }
backup="$dest.bak-$(date +%Y%m%d-%H%M%S)"
rsync -a --exclude venv --exclude '__pycache__' "$dest"/ "$backup"/
install -m 644 "$here/webhook/webhook_listener.py" "$here/webhook/godaddy.py" "$here/webhook/domaincheck.py" "$here/webhook/registrar.py" "$dest/"
# fake registrations are kept in a JSON file; the listener must be able to write there
mkdir -p /var/lib/kb-webhook
if [ -x "$dest/venv/bin/pip" ]; then
  "$dest/venv/bin/pip" install -q -r "$here/webhook/requirements.txt"
else
  echo "No venv at $dest/venv: make sure 'requests' is installed for the Python that runs the listener."
fi
for v in REGISTRAR REGISTRY_FILE DOMAIN_CHECK; do
  grep -q "^$v=" /etc/kb-webhook.env || echo "NOTE: $v is not in /etc/kb-webhook.env (see webhook/kb-webhook.env.example)"
done
# make sure the user running the listener can write the registry folder
svc_user="$(systemctl show -p User --value kb-webhook)"
[ -z "$svc_user" ] || chown "$svc_user" /var/lib/kb-webhook
systemctl restart kb-webhook
sleep 2
systemctl is-active kb-webhook
grep -c "process_domain" "$dest/webhook_listener.py" | sed 's/^/process_domain references in installed listener: /'
echo "Registrar mode: $(grep '^REGISTRAR=' /etc/kb-webhook.env || echo 'REGISTRAR not set, so fake')"
echo "Fake registrations are listed in /var/lib/kb-webhook/fake_registry.json"
echo "Backup of the old code: $backup"
