#!/usr/bin/env bash
# Uploads catalog/openstack-billing-plans-v3.xml as a new catalog version.
# Needs: KB_URL (default http://killbill.cloud.lab:8080), KB_ADMIN_PASSWORD, KB_API_KEY, KB_API_SECRET in the environment.
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
: "${KB_ADMIN_PASSWORD:?set KB_ADMIN_PASSWORD}" "${KB_API_KEY:?set KB_API_KEY}" "${KB_API_SECRET:?set KB_API_SECRET}"
curl -fsS -i -u "${KB_ADMIN_USER:-admin}:$KB_ADMIN_PASSWORD" \
  -X POST "${KB_URL:-http://killbill.cloud.lab:8080}/1.0/kb/catalog/xml" \
  -H "X-Killbill-ApiKey: $KB_API_KEY" -H "X-Killbill-ApiSecret: $KB_API_SECRET" \
  -H "X-Killbill-CreatedBy: admin" -H "Content-Type: text/xml" \
  --data-binary @"$here/catalog/openstack-billing-plans-v3.xml" | head -5
